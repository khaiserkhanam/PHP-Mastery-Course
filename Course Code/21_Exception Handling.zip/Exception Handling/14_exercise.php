<?php
// Find Odd Numbers

function printOddNumbers(int $num1,int $num2){
    if($num1<=0 || $num2<=0 || $num1==$num2){
        throw new Exception("Please enter valid number");
    }
    for($i=$num1;$i<=$num2;$i++){
        if($i%2!==0){
            echo "Odd Number : $i <br>";
        }
    }
}





function handle_exception($exception){
    echo $exception->getMessage();
}
// set_exception_handler('handle_exception');

// printOddNumbers(10,20);


try{
    printOddNumbers(10,0);
}catch(Exception $e){
    handle_exception($e);
}