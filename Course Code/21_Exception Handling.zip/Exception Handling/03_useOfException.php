<?php
function numberCheck($number){
    if($number>1){
        throw new Exception("Number must be one or less than 1");
    }
    return true;
}

// numberCheck(5);
// echo "hello";

// try{
//     numberCheck(1);
//     echo "hello";
// }catch(Exception $e){
//     echo $e->getMessage();
// }


// numberCheck(5);
// echo "hello";
// catch(Exception $e){
//     echo $e->getMessage();
// }