<?php
function my_custom_exception($exception){
    echo "Uncaught Error:".$exception->getMessage();
}
set_exception_handler('my_custom_exception');
// throw new Exception("Exception from our end");
// echo "This code will not be executed";

try{
    throw new Exception("Exception from our end");
}finally{
    echo "This code will  be executed";
}