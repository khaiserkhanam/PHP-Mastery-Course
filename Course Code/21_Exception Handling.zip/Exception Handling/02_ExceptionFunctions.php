<?php
function division($x,$y){
if($y<=0){
    throw new Exception("Division by zero is not possible");
}
$result=$x/$y;
return $result;
}

try{
$data=division(4,0);
echo $data;
}catch(Exception $e){
echo $e->getMessage();
}

// $data=division(4,0);
// echo $data;
echo "Iam executed";