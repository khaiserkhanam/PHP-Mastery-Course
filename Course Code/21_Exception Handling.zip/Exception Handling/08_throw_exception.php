<?php
function my_custom_exception($exception){
    echo "Uncaught Error:".$exception->getMessage();
}
set_exception_handler('my_custom_exception');
throw new Exception("Exception from our end");