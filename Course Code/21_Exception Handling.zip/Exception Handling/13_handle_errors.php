<?php
// EXAMPLE1
/*
function custom_warning_handler(){
    echo "Warning";
}
set_error_handler('custom_warning_handler');


echo $undefined_variable;
*/


// EXAMPLE2
/*function custom_warning_handler($errno , $errstr,$errfile,$errline){
    echo "Warning - $errstr - $errfile - $errline";
}
set_error_handler('custom_warning_handler');


echo $undefined_variable;
*/
// echo 3/0; -----not possible to handle division by zero error