<?php
// $number=0;
// $result=5/$number;
// echo $result;


// IF ELSE STATEMENT
// if($number>0){
//     $result=5/$number;
//     echo $result;  
// }else{
//     echo "Number cannot be divided by Zero!!";
// }

// TRY CATCH BLOCK

// try{
// if($number<=0){
//     throw new Exception("Number cannot be divided by Zero!!");
// }
// $result=5/$number;
//     echo $result;  
// }catch(Exception $e){
//     echo $e->getMessage();

// }