<?php

// echo 7/0;
// try{
//     echo 7/0;
// }catch(DivisionByZeroError $e){
//     echo "Caught Error ". $e->getMessage();
// }


// try{
//     echo 7/0;
    // throw new DivisionByZeroError("Hello");
// }catch(DivisionByZeroError $e){
//     echo "Caught Error ". $e->getMessage();
// }

// try{
//     echo 7/0;
//     throw new Exception("Hello");
// }catch(Exception $e){
//     echo "Caught Error ". $e->getMessage();
// }