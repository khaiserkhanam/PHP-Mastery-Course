<?php
function my_custom_exception($exception){
    echo "Uncaught Error:".$exception->getMessage();
}
set_exception_handler('my_custom_exception');

function divide($num1,$num2){
    try{
    if($num2<=0){
        throw new Exception("Enter valid number");
    }
    $result=$num1/$num2;
}catch(Exception $e){
    throw new Exception("Number cannot be divided by zero: ".$e->getMessage());
}
    return $result;
}

$answer=divide(34,0);
echo $answer;