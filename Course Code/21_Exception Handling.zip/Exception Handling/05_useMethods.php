<?php
function division($number){
    try{
if($number<=0){

    throw new Exception("Number cannot be zero",34);
}
$result=4/$number;
echo $result;
    }catch(Exception $e){
        // echo $e->getMessage();
        echo $e->getLine();
        // echo $e->getCode();
        // echo $e->getFile();

    }
}
division(0);
