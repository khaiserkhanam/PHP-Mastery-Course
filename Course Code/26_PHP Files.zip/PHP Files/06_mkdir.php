<?php
// mkdir("myFolder");

// if(file_exists("myFolder")){
//     echo "Folder already created";
// }else{
//     mkdir("myFolder"); 
// }


// if(!file_exists("data")){
//     mkdir("data"); 
//     echo "Folder  created";
// }else{
//     echo "Folder already created";
// }

