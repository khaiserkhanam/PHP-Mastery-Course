<?php
// $filePath="readme.txt";
// echo filesize($filePath);


// $filePath="02_copyfile.php";
// echo filesize($filePath);