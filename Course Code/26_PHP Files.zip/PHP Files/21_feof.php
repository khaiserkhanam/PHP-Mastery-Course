<?php
$file=fopen("readme.txt","r");
while(!feof($file)){
    $lineData=fgets($file);
    echo $lineData ."<br>";
}