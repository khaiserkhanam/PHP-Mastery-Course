<?php

// echo is_writable("31_isdir.php")?"It is a writable file":"It is not a  writable file";


// echo is_writeable("31_isdir.php")?"It is a writable file":"It is not a  writable file";