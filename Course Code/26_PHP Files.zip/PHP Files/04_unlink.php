<?php
// unlink("newFileCreated.txt");