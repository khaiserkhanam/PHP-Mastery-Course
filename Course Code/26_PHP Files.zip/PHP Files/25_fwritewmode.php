<?php

$file=fopen("readme.txt","w+");
fwrite($file,"Iam new data added");