<?php

// $filePath="readme.txt";

// echo "<pre>";
// print_r(pathinfo($filePath));
// echo "</pre>";

$filePath=realpath("readme.txt");
echo "<pre>";
print_r(pathinfo($filePath));
echo "</pre>";



// $filePath=realpath("readme.txt");
echo "<pre>";
print_r(pathinfo($filePath,PATHINFO_DIRNAME));
echo "</pre>";

echo "<pre>";
print_r(pathinfo($filePath,PATHINFO_BASENAME));
echo "</pre>";


echo "<pre>";
print_r(pathinfo($filePath,PATHINFO_EXTENSION));
echo "</pre>";

echo "<pre>";
print_r(pathinfo($filePath,PATHINFO_FILENAME));
echo "</pre>";