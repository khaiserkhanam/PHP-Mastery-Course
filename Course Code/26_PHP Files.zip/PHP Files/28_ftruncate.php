<?php

$file=fopen("readme.txt","a+");
ftruncate($file,50);