<?php
// copy("readme.txt","newFile.txt");
copy("readme.txt","otherfile.txt");