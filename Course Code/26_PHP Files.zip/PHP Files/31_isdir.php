<?php
// echo is_dir("Myfolder")?"It is a folder":"It is not a  folder";

// echo is_dir("31_isdir.php")?"It is a folder":"It is not a  folder";