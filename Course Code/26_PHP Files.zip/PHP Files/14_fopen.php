<?php
// fopen("readme.txt","r");

$file=fopen("readme.txt","r+");
fputs($file,"We have new line");
