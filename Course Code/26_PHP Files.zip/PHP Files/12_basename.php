<?php
$filePath="12_basename.php";
$fullpath=realpath($filePath);
// echo basename($fullpath);
echo basename($fullpath,'.php');