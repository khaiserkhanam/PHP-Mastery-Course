<?php
$file="otherFile.txt";

if(file_exists($file)){
    rename($file,"newFileCreated.txt");
}else{
    echo "File doesn't exists";
}