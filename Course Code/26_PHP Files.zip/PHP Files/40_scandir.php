<?php
// echo getcwd();
// echo "<pre>";
// print_r(scandir("."));
// echo "</pre>";


// echo "<pre>";
// print_r(glob("*"));
// echo "</pre>";


// $parent="..";
// echo getcwd();
// echo "<pre>";
// print_r(scandir($parent));
// echo "</pre>";
