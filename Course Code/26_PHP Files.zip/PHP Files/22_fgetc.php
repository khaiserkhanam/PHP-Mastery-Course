<?php
$file=fopen("readme.txt","r");
echo fgetc($file);
echo fgetc($file);