<?php
// echo readfile('readme.txt');

echo file_exists('readme.txt')?"File exist": "File doesnot exist";