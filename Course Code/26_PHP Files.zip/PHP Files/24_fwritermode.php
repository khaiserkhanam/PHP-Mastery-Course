<?php

$file=fopen("readme.txt","r+");
fwrite($file,"Iam new data added");