<?php
// $file=fopen("readme.txt","r");
// echo fread($file,65);


// $file=fopen("readme.txt","r");
// echo fread($file,filesize("readme.txt"));