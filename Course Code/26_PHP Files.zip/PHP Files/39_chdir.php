<?php
echo getcwd();
echo "<pre>";
print_r(glob("*"));
echo "</pre>";
chdir("Glob_Function");
echo "<br>";
echo getcwd();


echo "<pre>";
print_r(glob("*"));
echo "</pre>";