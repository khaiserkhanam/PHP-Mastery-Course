<?php

echo "<pre>";
print_r(file("readme.txt"));
echo "</pre>";