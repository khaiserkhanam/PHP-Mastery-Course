<?php
echo is_readable("31_isdir.php")?"It is a readable file":"It is not a  readable file";