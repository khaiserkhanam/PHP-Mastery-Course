<?php

   delete("newFile.txt");