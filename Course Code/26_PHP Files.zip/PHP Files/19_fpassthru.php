<?php
$file=fopen("readme.txt","r");
fseek($file,9);
echo ftell($file);
echo fpassthru($file);
