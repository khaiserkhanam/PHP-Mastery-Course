<?php

// $file=fopen("readme.txt","a+");
// fclose($file);


// $file=fopen("readme.txt","a+");
// fwrite($file,"Iam new data");
// fclose($file);
// fwrite($file,"Iam new data");