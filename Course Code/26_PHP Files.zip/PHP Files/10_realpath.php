<?php

$filePath="readme.txt";

echo realpath($filePath);