<?php
$file=fopen("readme.txt","r");
echo ftell($file);
echo fgets($file);
echo ftell($file);
echo fgets($file);
echo ftell($file);