<?php
// echo opendir(".");