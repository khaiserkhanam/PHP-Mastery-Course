<?php

// $filePath="readme.txt";
// echo filetype($filePath);

// mkdir("Myfolder");

// $filePath="Myfolder";
// echo filetype($filePath);