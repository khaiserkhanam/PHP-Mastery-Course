<?php
$file=fopen("readme.txt","r");
echo ftell($file);
echo fgets($file);
echo ftell($file);
echo fgets($file);
echo ftell($file);
fseek($file,0);
echo ftell($file);
echo fgets($file);