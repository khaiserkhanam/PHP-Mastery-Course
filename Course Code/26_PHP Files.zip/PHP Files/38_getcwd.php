<?php
echo getcwd();