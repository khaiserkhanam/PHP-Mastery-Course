<?php

// echo fileperms("readme.txt");
echo decoct(fileperms("readme.txt"));
