<?php
// is

// echo is_file("readme.txt")?"It is a file":"It is not a  file";


// echo is_file("Myfolder")?"It is a file":"It is not a  file";