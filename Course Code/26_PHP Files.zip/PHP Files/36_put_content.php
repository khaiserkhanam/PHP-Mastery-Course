<?php
// echo file_put_contents("readme.txt","Iam new data");


// echo file_put_contents("readme.txt","Iam new data",FILE_APPEND);


echo file_put_contents("readme.txt","Iam new data",FILE_APPEND | LOCK_EX);