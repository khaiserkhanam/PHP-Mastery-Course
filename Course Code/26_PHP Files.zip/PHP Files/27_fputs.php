<?php

$file=fopen("readme.txt","a+");
fputs($file,"Iam new data added");