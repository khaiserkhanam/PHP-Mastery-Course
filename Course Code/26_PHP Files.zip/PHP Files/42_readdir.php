<?php

// $data=opendir(".");
// print_r(readdir($data));


// $directory=".";
// if(is_dir($directory)){
//    if($opendir=opendir($directory)){
//     while($file=readdir($opendir)){
//         echo "Filename " . $file . "<br>";
//     }
//     closedir($opendir);
//    }

// }


// $directory="..";
// if(is_dir($directory)){
//    if($opendir=opendir($directory)){
//     while($file=readdir($opendir)){
//         echo "Filename " . $file . "<br>";
//     }
//     closedir($opendir);
//    }

// }


$directory="Glob_Function";
if(is_dir($directory)){
   if($opendir=opendir($directory)){
    while($file=readdir($opendir)){
        echo "Filename " . $file . "<br>";
    }
    closedir($opendir);
   }

}