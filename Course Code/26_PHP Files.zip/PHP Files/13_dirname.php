<?php

// $filepath="13_dirname.php";
// $fullpath=realpath($filepath);
// echo $fullpath;
// echo "<br>";
// echo dirname($fullpath);