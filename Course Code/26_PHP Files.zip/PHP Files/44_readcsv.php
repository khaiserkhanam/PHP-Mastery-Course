<?php

// $filename="person.csv";
// $data=file_get_contents($filename);
// echo $data;



// $csvfile=file("person.csv");
// var_dump($csvfile);
// foreach($csvfile  as $lineData){
//     echo $lineData . "<br>";
// }

$csvfile=file("person.csv");
// var_dump($csvfile);
foreach($csvfile  as $lineData){
    $data[]=str_getcsv($lineData);
    echo '<pre>';
    print_r($data);
    echo '</pre>';
}