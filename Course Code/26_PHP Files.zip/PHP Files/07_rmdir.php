<?php
// rmdir("data");


// if(file_exists("myFolder")){
//     rmdir("myFolder");
// }else{
//     echo "No such direcoty";
// }