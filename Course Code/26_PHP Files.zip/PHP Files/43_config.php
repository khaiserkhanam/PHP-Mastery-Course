<?php


$data=parse_ini_file('test.ini');
echo "<pre>";
print_r($data);
echo "</pre>";


// foreach($data as $values){
//     echo $values ."<br>";
// }

// foreach($data as $key=>$values){
//     echo "$key=>$values <br>";
// }

// echo $data['red'];