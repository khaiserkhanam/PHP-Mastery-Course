<?php

$data=glob("*");
echo "<pre>";
print_r($data);
echo "</pre>";


// $data=glob("*",GLOB_ONLYDIR);
// echo "<pre>";
// print_r($data);
// echo "</pre>";


// $data=glob("*",GLOB_MARK);
// echo "<pre>";
// print_r($data);
// echo "</pre>";

// $data=glob("z*");
// echo "<pre>";
// print_r($data);
// echo "</pre>";


// $data=glob("z*",GLOB_NOCHECK);
// echo "<pre>";
// print_r($data);
// echo "</pre>";



// $data=glob("*html,*php"); // wrong
// echo "<pre>";
// print_r($data);
// echo "</pre>";


// $data=glob("{*html,*php}",GLOB_BRACE);
// echo "<pre>";
// print_r($data);
// echo "</pre>";


// $data=glob("{js/*,php/*}",GLOB_BRACE);
// echo "<pre>";
// print_r($data);
// echo "</pre>";

// $data=glob("{js/*,php/*}");
// echo "<pre>";
// print_r($data);
// echo "</pre>";