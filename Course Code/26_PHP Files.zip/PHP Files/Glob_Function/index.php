<?php
// echo "<pre>";
// print_r(glob("*"));
// echo "</pre>";


// echo "<pre>";
// print_r(glob("php/*"));
// echo "</pre>";


// echo "<pre>";
// print_r(glob("*.html"));
// echo "</pre>";


// echo "<pre>";
// print_r(glob("*.php"));
// echo "</pre>";


// echo "<pre>";
// print_r(glob("r*"));
// echo "</pre>";


// echo "<pre>";
// print_r(glob("*nd*"));
// echo "</pre>";

// echo "<pre>";
// print_r(glob("in*ml"));
// echo "</pre>";




// echo "<pre>";
// print_r(glob("[ir]*"));
// echo "</pre>";


// echo "<pre>";
// print_r(glob("js/m*"));
// echo "</pre>";


// $data=glob("*");
// foreach($data as $filetype){
// echo "$filetype:". filetype($filetype);
// echo "<br>";
// }


// $data=glob("*");
// foreach($data as $filetype){
// echo "$filetype:". realpath($filetype);
// echo "<br>";
// }


// $data=glob("*");
// foreach($data as $filetype){
// echo "$filetype:". filesize($filetype);
// echo "<br>";
// }