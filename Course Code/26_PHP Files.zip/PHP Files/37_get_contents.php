<?php
// echo file_get_contents("readme.txt");

echo file_get_contents("readme.txt",FALSE,NULL,0,10);