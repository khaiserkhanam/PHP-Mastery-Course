<?php
$file=fopen("readme.txt","r");
fseek($file,9);
echo ftell($file);
rewind($file);
echo ftell($file);