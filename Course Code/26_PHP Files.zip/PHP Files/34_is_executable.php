<?php

// echo is_executable("31_isdir.php")?"It is a executable file":"It is not a  executable file";