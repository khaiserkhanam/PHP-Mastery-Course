<!-- PHP Casting Strings and Floats to Integers -->
<?php


// (int)  (integer)  (intval)


// casting float to integer
// $x=45.9568;
// var_dump($x);
// echo "<br>";
// $int_casting=(int)$x;
// var_dump($int_casting);




// casting string to integer

// $y="748";
// var_dump($y);
// echo "<br>";
// $int_casting=(integer)$y;
// var_dump($int_casting);


// $y="748.98";
// var_dump($y);
// echo "<br>";
// $int_casting=(integer)$y;
// var_dump($int_casting);