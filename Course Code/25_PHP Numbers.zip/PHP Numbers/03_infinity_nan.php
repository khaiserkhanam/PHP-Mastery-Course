<?php
// echo PHP_FLOAT_MAX;
// echo "<br>";

// $number=1.7976931348623E+408;
// echo $number;
// var_dump($number);
// echo "<br>";
// echo is_infinite($number)?"It is infinite number": "It is not infinite number";


// $data=1.7976931348623E+310;
// echo $data;
// echo "<br>";
// var_dump($data);
// echo "<br>";
// echo is_finite($data)?"It is finite number": "It is not finite number";

// NAN

// $x=acos(9);
// var_dump($x);

// echo is_nan($x);