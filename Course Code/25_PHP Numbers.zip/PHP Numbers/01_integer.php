<?php
// * 8,87,888, -876, 3345 are all integers.
// * An integer is a number without any decimal part.
// * An integer data type is a non-decimal number between -2147483648 and 2147483647 in 32 bit systems, and between -9223372036854775808 and 9223372036854775807 in 64 bit systems. A value greater (or lower) than this, will be stored as float, because it exceeds the limit of an integer.
// * Note: Another important thing to know is that even if 2 * 5.5 is 11, the result is stored as float, because one of the operands is a float (5.5).
// * An integer must have at least one digit
// * An integer must NOT have a decimal point
// *An integer can be either positive or negative

// $a=5;
// $b=6.7;
// $c="90";


// var_dump($a);
// var_dump($b);
// var_dump($c);


// $multiply=2*5.5;
// echo $multiply;
// var_dump($multiply);


// echo PHP_INT_MAX;
// echo "<br>";
// $data=9223372036854775900;
// echo $data;

// echo PHP_INT_MIN;
// echo "<br>";
// echo PHP_INT_SIZE;


// $a=5;
// $b=6.7;
// $c="90";

// echo is_int($a)?"It is an integer": "It is not an integer";
// echo is_int($b)?"It is an integer": "It is not an integer";
// echo is_int($c)?"It is an integer": "It is not an integer";


// echo is_integer($a)?"It is an integer": "It is not an integer";
// echo is_integer($b)?"It is an integer": "It is not an integer";
// echo is_integer($c)?"It is an integer": "It is not an integer";


// echo is_long($a)?"It is an integer": "It is not an integer";
// echo is_long($b)?"It is an integer": "It is not an integer";
// echo is_long($c)?"It is an integer": "It is not an integer";