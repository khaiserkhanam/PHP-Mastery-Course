<?php

// $x=87;
// var_dump(is_numeric($x));

// $y="76";
// var_dump(is_numeric($y));


// $z="76"+90;
// echo $z;
// var_dump(is_numeric($z));



// $z="Hello";
// var_dump(is_numeric($z));