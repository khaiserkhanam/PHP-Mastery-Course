<?php
/*
* A float is a number with a decimal point or a number in exponential form.
* 3.0, 876.66, , 4.56E+5,7.91E-5 are all floats.
* The float data type can commonly store a value up to 1.7976931348623E+308 (platform dependent), and have a maximum precision of 14 digits.
*/

// $data=1.1;
// echo $data;
// var_dump($data);

// $result=2*5.5;
// echo $result;
// var_dump($result);

// $data=1.0;
// echo $data;
// var_dump($data);

// echo PHP_FLOAT_MAX;
// echo "<br>";

// echo PHP_FLOAT_MIN;
// echo "<br>";

// echo PHP_FLOAT_DIG;


// $data=1.0;
// echo $data;
// var_dump($data);
// echo is_float($data)?"It is float": "It is not float";
// echo is_double($data)?"It is float": "It is not float";