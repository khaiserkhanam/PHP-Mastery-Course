<?php
echo "Welcome to my website";
echo "Welcome to my website";
echo "Welcome to my website";
echo "Welcome to my website";
echo "Welcome to my website";
echo "Welcome to my website";
echo "Welcome to my website";
echo "Welcome to my website";

//👉Define a Function
function message(){
    echo "Welcome to my website";
}
//👉Calling /invoking /running
message();
message();

//👉Can we have Duplicate Functions ?

function add(){
    $num1=5;
    $num2=5;
    $result=$num1+$num2;
    echo $result;
}
add();
// function add(){
//     $num1=5;
//     $num2=5;
//     $result=$num1+$num2;
//     echo $result;
// }
// add();


//👉Can we call function before declaration?
add1();
function add1(){
    $num1=5;
    $num2=5;
    $result=$num1+$num2;
    echo $result;
}
add1();