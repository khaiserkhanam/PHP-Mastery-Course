<?php
echo "MAGIC CONSTANTS";

// echo "My name is Khanam" . __LINE__;
// echo "My name is Khanam" . __FILE__;
// echo "My name is Khanam" . __DIR__;

function myData(){
    echo __FUNCTION__;
}
myData();

