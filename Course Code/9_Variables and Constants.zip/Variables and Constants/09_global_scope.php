<?php
$language="PHP";
function language_display(){
    $language="Backend";
    echo $language;
}
language_display();
echo $language;

// 👉Define global variable
global $language;
$language="PHP";
function language_display(){
    $language="Backend";
    echo $language;
}
language_display();
echo $language;

// 👉How to access the global variable inside the function?
global $language;
$language="PHP";
function language_display(){
    echo $language;
}
language_display();
echo $language;

// global $language;
$language="PHP";
echo $language;
function language_display(){
    global $language;
    $language="Backend";
    echo $language;
}
language_display();
echo $language;
