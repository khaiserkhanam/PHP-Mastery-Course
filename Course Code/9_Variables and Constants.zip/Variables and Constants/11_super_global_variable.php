<?php

// 👉$_SERVER

// echo $_SERVER['PHP_SELF'];
// echo $_SERVER['SERVER_NAME'];


// 👉$GLOBALS

$num=10;
// echo $num;
// echo $GLOBALS['num'];
function data(){
    echo $GLOBALS['num'];
    $GLOBALS['num']=30;
    echo $GLOBALS['num'];
}
data();
echo $num;