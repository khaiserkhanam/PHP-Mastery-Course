<?php
// 👉Variables of Variables
$fruit="apple";
echo $fruit;
$$fruit ="red";     //$(apple)=$apple
echo $fruit;
echo $apple;

$variablename="dynamicvar";
$$variablename="Greeting ";
echo $variablename;
echo $$variablename;
echo $dynamicvar;

// $100=00;
$num=100;
$$num=200;
//$(100)= $100;
echo $$num;
echo ${'100'};