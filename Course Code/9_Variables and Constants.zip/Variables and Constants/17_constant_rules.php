<?php
// Rules of creating constants
// define('MAXVALUE',100);
// echo MAXVALUE;

// define('MAX_VALUE',100);
// echo MAX_VALUE;

// define('PI',3.14);
// echo PI;

// function constant1(){
//     echo PI;
// }
// constant1();

// define('MY_NAME');
// define('MY_NAME','Khanam');
// echo MY_NAME;

// define('IF','loop');
// echo IF;