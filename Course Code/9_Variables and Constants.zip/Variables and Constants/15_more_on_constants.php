<?php
// define('MYNAME','Khanam');
// echo MYNAME;
// define('MYNAME','Saniya');
// echo MYNAME;


// $fruit="apple";
// $FRUIT="apple";
// echo $FRUIT;
// define('FRUIT','mango');
// echo FRUIT;


// define('PI',"");
// echo isset(PI);

// define("SUBJECT",'PHP');
// echo SUBJECT;
// echo constant('SUBJECT');