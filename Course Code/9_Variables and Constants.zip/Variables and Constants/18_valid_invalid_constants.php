<?php
// Valid and Invalid Constants

// define("MAX_VALUE", 100);  //valid
// define("myConstant", "Invalid Constants");
// define("INVALID_CONSTANT_", "Invalid Constants"); 
// define("123_CONSTANT", "Invalid Constants"); 
// define("IF", "Invalid Constants"); 

// $value = 42;
// define("DYNAMIC_CONSTANT", $value); 
// echo DYNAMIC_CONSTANT;

// $value = 56;
// echo DYNAMIC_CONSTANT;

// $LANGUAGE='JAVASCRIPT';
// echo $LANGUAGE;
// define('_LANGUAGE','PHP');
// echo _LANGUAGE;