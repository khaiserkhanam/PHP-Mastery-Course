<?php
$fruit="apple";
$fruit='apple';
echo $fruit;

echo "An $fruit a day keeps doctor way";
echo 'An $fruit a day keeps doctor way';


$fruit="apple";
$fruit='apple';
$color="red";
echo $fruit;

echo "An $fruit a day keeps doctor way";
echo 'An $fruit a day keeps doctor way';
echo "$fruit-$color";
echo "$fruit".'$color';
echo $fruit.$color;