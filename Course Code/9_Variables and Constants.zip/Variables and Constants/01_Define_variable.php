<?php

//👉 Declaring variables
$myname;


//👉Defining variable
$myname="Khanam";  //String Datatype
$age=10;  //Integer data type