<?PHP
// 👉Does case sensitivity apply for all? 
$myname="Khanam";
$Myname="Saniya";
echo $myname;
ECHO $Myname;
EcHO $Myname;

function message(){
    echo "Welcome to PHP Language";
}
message();
// function MESSAGE(){
//     echo "Welcome to PHP Language";
// }
// message();