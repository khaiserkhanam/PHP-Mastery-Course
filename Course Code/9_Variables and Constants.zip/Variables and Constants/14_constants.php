<?php
// What are constants?
// value will not change throug out the program
// define(name,value);


// define('PI',3.14);
// echo PI;
// echo 'PI';
// echo "PI";

// define("GREETING","Hello Students");
// echo GREETING;
// define("GREETING","Hello Students");
// echo GREETING;
// $greet=GREETING;
// echo "$greet";

// function hello(){
//     echo GREETING;
// }
// hello();