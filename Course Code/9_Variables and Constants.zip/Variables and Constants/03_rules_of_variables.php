<?php
// 👉 Case Sensitive
$fruit="apple";
echo $fruit;
// echo $FRUIT;

// 👉 Start with underscore or alphabet after underscore
$_color="red";
echo $_color;

// 👉 Can have numbers(0-9) a-z A-Z _ in between
$vegetable1="brinjal";
echo $vegetable1;

// 👉Cannot have any special characters
$vegetable1%="brinjal";
echo $vegetable1%;

// 👉Cannot start with number after dollar sign
$100apple// invalid variable

// 👉 No space in between
$firt name="Saniya";
echo $firt name;
$lastname="Sharma";

$firt_name="Saniya";
echo $firt_name;
$lastname="Sharma";

// 👉Good Practice : Do not use reserve words like else if while function
$else="else";
echo $else;


// int $age=10;
$age=10;
echo $age;

echo "$age";

$white="color of cat";
echo $white;

$number=1;
$number="One";