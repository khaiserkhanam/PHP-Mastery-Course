<?php
//👉 STATIC SCOPE
function series(){
    static $num;
    // var_dump($num);
    echo $num ."<br>";
    $num=$num+2;
}
series();
series();
series();
series();
series();
series();
series();
series();
// echo $num ."<br>";