<!--  Working with DataTypes-->
<?php
//👉Can variable change its value?
$myname="Khanam";
echo $myname;
$myname="Iam an intructor";
echo $myname;


//👉Define a String Variable
$language="PHP";
$message="I Love";
echo $message;

//👉Combining Strings
echo $language;
$result=$message."-".$language;
echo $result;

//👉String Interpolation
echo "$message-$language";
echo "message-$language";

//👉Define a Integer variable
$age=20;
echo $age;


//👉Can we combine different datatype variables and print it?
echo "$myname $age";
echo "My name is ".$myname." and Iam".$age." years old";
echo "My name is $myname and Iam $age years old";