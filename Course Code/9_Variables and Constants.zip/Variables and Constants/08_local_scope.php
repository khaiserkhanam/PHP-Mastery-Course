<?php

// 👉LOCAL VARIABLES
// $language="PHP";
// function language_display(){
//     $language="Backend";
//     echo $language;
// }
// echo $language;
// language_display();

// 👉VARIABLE SCOPING
// $language="PHP";
// function language_display1(){
//     echo $language;
// }
// language_display1();
// echo $language;