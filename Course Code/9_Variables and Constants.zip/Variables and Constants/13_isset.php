<?php
// 👉Example
$age;
// echo $age;
if(isset($age)){
    echo "Variable is set";
}else{
    echo "Variable is not set";
}

// 👉Example
$fruit="mango";
if(isset($fruit)){
    echo "$fruit Variable is set";
}else{
    echo "Variable is not set";
}

// 👉Example
$fruit="mango";
$ref=$fruit;
if(isset($ref)){
    echo "Variable is set";
}else{
    echo "Variable is not set";
}

// 👉Example
$fruit;
$ref=$fruit;
if(isset($ref)){
    echo "Variable is set";
}else{
    echo "Variable is not set";
}