<?php

$num1=10;
$num2=20;
$result=$num1*$num2;
echo $result;


$num1="10";
var_dump($num1);
$num2=20;
var_dump($num2);
$result=$num1*$num2;
echo $result;
var_dump($result);

$num1="apple";
var_dump($num1);
$num2=20;
var_dump($num2);
$result=$num1*$num2;
echo $result;
var_dump($result);

$age=34;
var_dump($age);
$stringConvert=(string) $age;
var_dump($stringConvert);

function add(){
    $num1=5;
    $num2=5;
    $result=$num1+$num2;
    echo $result;
}
add();