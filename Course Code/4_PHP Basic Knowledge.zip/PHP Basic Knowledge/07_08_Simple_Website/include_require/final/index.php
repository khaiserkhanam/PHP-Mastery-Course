<?php include 'header.php'  ?>
<?php include 'header.php'  ?>

    <div class="main">
        <div class="left">
            <h1> Home Page Content</h1>
        </div>
       <?php include 'sidebar.php'?>
    </div>
<?php include 'footer.php'?>
<?php include 'header.php'  ?>