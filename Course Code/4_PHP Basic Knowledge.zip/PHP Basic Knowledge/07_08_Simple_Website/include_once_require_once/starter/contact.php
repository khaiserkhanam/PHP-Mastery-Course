<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="header">
       <h1> Header</h1>
       <ul>
        <li><a href="index.php">Home page</a></li>
        <li><a href="about.php" >About page</a></li>
        <li><a href="contact.php">Contact page</a></li>
       </ul>
    </div>
    <div class="main">
        <div class="left">
            <h1> Contact Page Content</h1>
        </div>
        <div class="right">
            <h1> Side bar</h1>
        </div>
    </div>
    <div class="footer">
        <h1>Footer</h1>
    </div>
    
</body>
</html>