<div class="footer">
        <h1>Footer</h1>
    </div>
    </body>
</html>