<?php require 'headerrrrrrr.php'  ?>
    <div class="main">
        <div class="left">
            <h1> About Page Content</h1>
        </div>
        <?php require 'sidebar.php'?>
    </div>
    
    <?php include 'footer.php'?>