<div class="right">
            <h1> Side bar</h1>
        </div>