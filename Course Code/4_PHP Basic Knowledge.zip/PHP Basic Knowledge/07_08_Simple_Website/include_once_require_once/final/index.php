<?php include_once 'header.php'  ?>


    <div class="main">
        <div class="left">
            <h1> Home Page Content</h1>
        </div>
       <?php include_once 'sidebars.php'?>
    </div>
<?php include 'footer.php'?>