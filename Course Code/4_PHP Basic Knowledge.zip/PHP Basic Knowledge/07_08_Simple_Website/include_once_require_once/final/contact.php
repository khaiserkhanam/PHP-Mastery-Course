<?php include 'header.php'  ?>

    <div class="main">
        <div class="left">
            <h1> Contact Page Content</h1>
        </div>
        <?php require_once 'sidebarsss.php'?>
    </div>
    <?php require_once 'footer.php'?>   


