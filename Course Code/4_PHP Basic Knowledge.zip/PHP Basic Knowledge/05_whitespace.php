













<?php














echo "Whitespace                
PHP"

?>