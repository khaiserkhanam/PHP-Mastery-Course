<!-- 1. single line //
2. hash comments #
3. Multi line  /*     */ -->


<?php

// echo "Hello";
#echo "Hello";
/* echo "Hello


World"*/

/*
//1. single line 
#2. hash /*com/*ments
3. Multi line*/

?>

<!-- HTML comments -->
hello

<!-- <?php
echo "comments";
?> -->


<?php
echo "<!--comments-->";
?>


<?php

4+6+/*7*/+8
?>