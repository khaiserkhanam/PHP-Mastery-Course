<!-- 
\n - New Line - <br>
\t - Tab - &nbsp;&nbsp;
\$ - Dollar Sign
\" - Double Quotes
\' - Single Quotes
\\ - Single Backslash -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Escape Characters</title>
</head>
<body>
    <p><?php echo "Escape characters <br>
    in PHP are very &nbsp; \"important\" to structure the content and its worth 100 \$ content";?></p>
    <p><?php echo 'I\'am';?></p>
</body>
</html>