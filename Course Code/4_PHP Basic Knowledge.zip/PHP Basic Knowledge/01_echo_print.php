<!-- <?php

?> -->

<?php

echo "Khanam";
?>
<?php

print "Khanam";
?>

<?= "Hello";?>



<?= "Hello"?>


<!-- Differences -->
<!-- 1. -->
<?php
// $data=echo "PHP";
$data1=print "PHP 1";
?>

<!-- 2. -->
<?php
echo "Hello","World";
// echo ("Hello","World");
print ("Hello World");
?>