<?php include 'header.php' ?>
    <div class="main">
    <h3><?php echo "'Exploring' &nbsp;	the world with curiosity" ?></h3>
    </div>
    <?php require 'footer.php'?>