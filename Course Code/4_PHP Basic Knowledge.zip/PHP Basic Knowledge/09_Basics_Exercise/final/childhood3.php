<?php include 'header.php' ?>
    <div class="main">
    <h3><?php echo '"Imagination":<br> knows no bounds in childhood' 

    ?></h3>
    </div>
    <?php require 'footer.php'?>