<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Childhood memories</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="header">
       <ul>
        <li><a href="childhood1.php">Childhood1</a></li>
        <li><a href="childhood2.php">Childhood2</a></li>
        <li><a href="childhood3.php">Childhood3</a></li>
        <li><a href="childhood4.php">Childhood4</a></li>
       </ul>
    </div>