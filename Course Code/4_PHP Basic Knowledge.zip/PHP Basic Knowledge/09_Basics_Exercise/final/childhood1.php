<?php include 'header.php' ?>
<?php //include 'header.php' ?>
<?php /*include 'header.php' */?>
<?php //include 'header.php' ?>
<?php #include 'header.php' ?>
    <div class="main">
       <h3><?php echo	"\"Childhood\" memories are treasures forever"   ?></h3>
    </div>
<?php require 'footer.php'?>
