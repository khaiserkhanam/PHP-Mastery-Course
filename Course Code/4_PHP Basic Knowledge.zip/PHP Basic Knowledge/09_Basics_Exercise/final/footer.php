<div class="footer">
        <p>All Rights Reserved &copy;</p>
    </div>
    
</body>
</html>