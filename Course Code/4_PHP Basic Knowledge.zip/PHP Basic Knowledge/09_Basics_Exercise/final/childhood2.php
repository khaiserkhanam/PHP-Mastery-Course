<?php include 'header.php' ?>
    <div class="main">
    <h3><?php echo "'Innocence' and laughter define childhood"  ?></h3>
    </div>
    <?php require 'footer.php'?>