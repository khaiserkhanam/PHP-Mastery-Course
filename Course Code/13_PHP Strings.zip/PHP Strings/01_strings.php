<?php
// In PHP, a string is a sequence of characters, which can be letters, numbers, symbols, or any combination . Strings can be created using single quotes (') or double quotes ("), and PHP provides a variety of functions and operators to manipulate and work with strings.  


// $str1="Hello world";
// echo $str1;
// $str2='Hello world1';
// echo $str2;

// $result=$str1. "-".$str2;
// echo $result;

// $number=1;
// $islogin=true;
// $data=$number.$islogin;
// echo $data;
// var_dump($data);