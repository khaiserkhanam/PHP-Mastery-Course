<?php
    // str_replace(mixed $search, mixed $replace, mixed $array, int &$count = null): mixed


    // $string="Sample sentence Sample Sample";
    // $result=str_replace("Sample","Example", $string);
    // $result=str_replace("Sample","Example", $string,$count);
    // echo $string;
    // echo $result;
    // echo $count;
    

      $string=["Sample sentence","Another Sample sentence","Yet another sample"];
      $result=str_replace("sentence","data",$string);
      print_r($result);