<?php
// substr(string, start,length);
// $string="Hello World people";
// $substring=substr($string,6,5);
// $substring=substr($string,6);
// $substring=substr($string);
// echo $substring;





// NUMBER FUNCTIONS
// is_numeric();
echo is_numeric("1");
echo is_numeric("12");
echo is_numeric(12)?"Its is number":"It is not a number";
echo is_numeric('12cd')?"Its is number":"It is not a number";
echo is_numeric('12.89');


// intval();
echo intval(12);
echo intval('12sd');
echo intval('20.09');
