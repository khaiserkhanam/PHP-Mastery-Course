<?php
$myname="Khanam";
// $result=strlen($myname);
// echo $result;

// $data="";
// $result=strlen($data);
// echo $result;


// $data=0;
// $result=strlen($data);
// echo $result;


$data="Khanam";
$result=strlen($data);
echo $result;

// if(strlen($data)>0){
//     echo $data;
// }else{
//     echo "It is empty";
// }


if(!empty($data)){
    echo $data;
   
}else{
    echo "it is empty";
}