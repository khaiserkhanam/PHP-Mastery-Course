<?php
echo strtoupper("sTriNg");

$string="hello world";
$uppercase=strtoupper($string);
echo $uppercase;
echo $string;


$string2="My name is Khanam";
$lowercase=strtolower($string2);
echo $lowercase;
echo $string2;