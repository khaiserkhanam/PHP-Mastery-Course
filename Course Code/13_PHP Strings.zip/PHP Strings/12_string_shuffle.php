<?php

$result="string";
$data=str_shuffle($result);
echo $data;