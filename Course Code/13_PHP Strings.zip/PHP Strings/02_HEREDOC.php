<?php
$myname="Khanam";
$age=25;


$data=<<<EOD
"My name is '$myname'"
My age is $age
I like to play with star pattern
*
**
***
****
Multiply your name with three ($myname * 3);
Output: $myname$myname$myname
(condition) ? "True statement" : "False statement"

EOD;    

echo "<pre>".$data."</pre>";

// $result=(condition) ? "True statement" : "False statement"
// echo $result;