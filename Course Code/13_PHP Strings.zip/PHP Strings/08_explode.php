<?php
// explode(string $delimiter, string $string, int $limit = PHP_INT_MAX): array

$fruit="apple|mango|grapes,banana";
// echo $fruit;
$result=explode("|",$fruit);
// $result=explode(",",$fruit,3);
print_r($result);

