<?php
// The wordwrap function in PHP is used to wrap a string to a given number of characters. It inserts line breaks ("\n") into the string at specified intervals to ensure that no line exceeds the given length.

// wordwrap(string $str, int $width = 75, string $break = "<br>" );

$content="This is a very long content and it is a string.";
$wordwrap=wordwrap($content,7,"<br>",true);
echo $wordwrap;

