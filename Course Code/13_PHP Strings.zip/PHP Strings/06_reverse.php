<?php

$data="hello world"; //olleh
// echo strrev("hello");
echo strrev($data);