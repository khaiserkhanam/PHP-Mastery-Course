<?php
// Syntax
// strpos($string,$searchdata)

// $stringData="The strpos function in PHP is used to find the position of the first occurrence of a substring in a string.";
// $position="The";
// $result=strpos($stringData,$position);
// echo $result?"Position is found":"Position is not found";
// echo $result;



// echo $result?"Position is found":"Position is not found";
// echo !$result?"Position is not found":"Position is found";

// if(!0){
//     echo "position not found";
// }

// echo false;

// if($result===false){
//     echo "Position not found";
// }else{
//     echo "Position  found";
// }


// echo ($result===false)?"Position not found":"Position  found";