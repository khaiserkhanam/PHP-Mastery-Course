<?php

// implode(string $separator, array $arr): string

// SA=E
// AS=I
$vegetable=["brinjal","cucumber","bottleneck"];
print_r($vegetable);
$result=implode("|",$vegetable);
echo $result;
var_dump($result);