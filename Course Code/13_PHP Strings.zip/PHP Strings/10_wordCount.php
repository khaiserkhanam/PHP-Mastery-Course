<?php
$str1="Iam simple sentence";
$result1=str_word_count($str1,1);
$result2=str_word_count($str1,2);
// echo $result;
print_r($result1);
echo "<br>";
print_r($result2);



