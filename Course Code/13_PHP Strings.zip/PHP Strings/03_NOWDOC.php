<?php
$myname="Khanam";
$age=25;

$data=<<<'mylabel'
"My name is '$myname'"
My age is $age
I like to play with star pattern
*
**
***
****
Multiply your name with three ($myname * 3);
Output: $myname$myname$myname
(condition) ? "True statement" : "False statement"

mylabel;

echo "<pre>".$data."</pre>";