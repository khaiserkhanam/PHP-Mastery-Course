
<?php
// $GLOBALS

// Example 1
// $myname="Khanam";
// echo $myname;

// function displayName(){
//     echo $myname;
// }
// displayName();


// Example 2
// global $myname;
// $myname="Khanam";
// echo $myname;

// function displayName(){
//     global $myname;
//     echo $myname;
// }
// displayName();

// Example 3
// $myname="Saniya";
// $GLOBALS['myname'];
// echo $GLOBALS['myname'];

// function displayName(){
//     echo $GLOBALS['myname'];
// }
// displayName();

// Example4


// function displayName(){
//     $GLOBALS['data']=900;
// }
// displayName();
// echo $GLOBALS['data'];
// echo $data;