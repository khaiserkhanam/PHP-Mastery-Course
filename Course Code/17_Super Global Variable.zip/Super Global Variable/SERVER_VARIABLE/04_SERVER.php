<?php
if(isset($_GET['submit'])){
    echo $_GET['username'];
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Global Variable</title>
</head>
<body>
    <h1>$_SERVER- Super Global Variable </h1>
    <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="get">
        <input type="text" name="username" placeholder="Enter your name" autocomplete="off"><br><br>
        <input type="age" name="age" placeholder="Enter your age" autocomplete="off"><br><br>
        <input type="submit" name="submit"><br><br>
    </form>
</body>
</html>