<?php
setcookie("Food","Pizza",time()-86400,"/");
echo "Cookie is deleted";