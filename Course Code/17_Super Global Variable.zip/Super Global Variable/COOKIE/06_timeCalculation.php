<?php
// $category_name="Food";
// $category_value="Pizza";


// setcookie($category_name,$category_value,time()+86400,"/");
// echo "Cookie is set";

// time(): current time
// + time in seconds

// 1min=60 seconds
// 60min(1hr)=60*60= 3600
// 24 hr=3600*24=86400
// 2days =(86400*2)
// 30days = (86400*30)


// setcookie("Gadgets","Mobile",time()+3,"/");
// echo "Cookie is set";




?>