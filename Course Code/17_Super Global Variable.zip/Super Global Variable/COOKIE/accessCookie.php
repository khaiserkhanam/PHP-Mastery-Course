<?php
echo $_COOKIE["Food"];