<?php
print_r($_POST);
echo "<br>";
echo $_POST['username'];
$name= $_POST['username'];
echo $name;