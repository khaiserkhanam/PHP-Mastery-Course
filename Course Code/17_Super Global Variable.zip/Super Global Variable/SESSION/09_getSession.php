<?php
// session_start();
// echo $_SESSION['food'];


// Example 2
// session_start();
// echo "Welcome". $_SESSION['username'];
// echo "<br>";
// echo "Your email is is ". $_SESSION['email'];
// echo "<br>";


// Example3
// session_start();
// if(isset($_SESSION['username'])){
// echo "Welcome". $_SESSION['username'];
// echo "<br>";
// echo "Your email is is ". $_SESSION['email'];
// echo "<br>";
// }
// else{
//     echo "Please login again";
// }
