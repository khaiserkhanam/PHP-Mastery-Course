<?php

// Example1
// session_start();

// $_SESSION['food']="biryani";

// echo "Session is set";

// print_r( $_SESSION);
// echo $_SESSION['food'];


// Example2
// session_start();
// $_SESSION['username']="Khanam";
// $_SESSION['email']="khanam@gmail.com";
// echo "Session is set <br>";

// echo "Welcome". $_SESSION['username'];
// echo "<br>";
// echo "Your email is is ". $_SESSION['email'];
// echo "<br>";
