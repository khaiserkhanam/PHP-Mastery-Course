<?php
print_r($_GET);
echo "<br>";
echo $_GET['username'];