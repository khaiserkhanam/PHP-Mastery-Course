<?php
if(isset($_POST['submit'])){
    $image=$_FILES['image_file'];
    echo "<pre>";
    print_r($image);
    echo "</pre>";
    echo $image['name'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image</title>
</head>
<body>
    <form action="" method="post" enctype="multipart/form-data">
        <input type="file" name="image_file">
        <br>
        <br>
        <input type="submit" name="submit">
    </form>
    
</body>
</html>
