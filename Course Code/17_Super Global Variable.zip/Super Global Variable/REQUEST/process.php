<?php
// print_r($_REQUEST);
// echo "<br>";
// print_r($_POST);



print_r($_REQUEST);
echo "<br>";
print_r($_GET);