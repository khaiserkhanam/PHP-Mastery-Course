<?php
// UPDATE ARRAY ELEMENTS
// $employeeData=[102,"Khanam",25,true,23000];
// echo "<pre>";
// print_r($employeeData);
// echo "</pre>";


// echo "<br>";

// Change complete array
// $employeeData="Khanam";
// print_r($employeeData);
// echo $employeeData;


// UPDATE INDIVIDUAL  ELEMENTS
// echo $employeeData[1];
// $employeeData[1]="Riya";
// echo $employeeData[1];
// echo "<pre>";
// print_r($employeeData);
// echo "</pre>";


// CHANGE DATA TYPE OF ELEMENTS
// var_dump($employeeData);
// $employeeData[4]=23000.00;
// echo "<pre>";
// print_r($employeeData);
// echo "</pre>";
// echo "<br>";
// var_dump($employeeData);


// RESTRUCTURE COMPLETE ARRAY
// $employeeData=[102,"Khanam",25,true,23000];
// echo "<pre>";
// print_r($employeeData);
// echo "</pre>";


// echo "<br>";
// var_dump($employeeData);

// $employeeData[0]="Saniya";
// $employeeData[1]=109;
// $employeeData[2]=0;
// $employeeData[3]=30;
// $employeeData[4]=45000.09;
// echo "<pre>";
// print_r($employeeData);
// echo "</pre>";
// echo "<br>";
// var_dump($employeeData);