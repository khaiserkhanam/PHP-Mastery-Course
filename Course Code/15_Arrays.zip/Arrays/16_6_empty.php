<?php
$data=[];
$fruits = ["apple", "banana", "cherry", "date", "elderberry"];

echo empty($data)?"It is empty":"It is not empty";
echo "<br>";
echo empty($fruits)?"It is empty":"It is not empty";
echo "<br>";