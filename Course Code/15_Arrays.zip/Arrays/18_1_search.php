<?php
$fruits = ["apple", "banana", "cherry", "date", "elderberry"];

// $key=array_search("banana",$fruits);
// echo $key;

// $key=array_search("pineapple",$fruits);
// echo $key;

// $key=array_search("apple",$fruits);
// echo $key;

// if($key){
//     echo "element is present";
// }else{
//     echo "element is not present";
// }

$key=array_search("pineapple",$fruits);
echo $key;

if($key!==false){ 
    echo "Element is present at $key position";
}else{
    echo "Element is not present";
}