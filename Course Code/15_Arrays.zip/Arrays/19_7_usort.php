<?php
$numbers = [4, 2, 8, 1, 5];
function compareNumbers($a,$b){
    return $b-$a;
}
usort($numbers,'compareNumbers');
echo "<pre>";
print_r($numbers);
echo "</pre>";