<?php
// $fruits = ["apple", "banana", "cherry","mango"];
// echo "<pre>";
// print_r($fruits);
// echo "</pre>";

// $fruits[]="pineapple";
// echo "<pre>";
// print_r($fruits);
// echo "</pre>";

// $fruits[7]="grapes";
// echo "<pre>";
// print_r($fruits);
// echo "</pre>";


// $fruits[]="tomato";
// echo "<pre>";
// print_r($fruits);
// echo "</pre>";


// $fruits = [1, "banana", 2,"mango"];
// echo "<pre>";
// print_r($fruits);
// echo "</pre>";

// $fruits[]=[1, "banana", 2,"mango"];
// echo "<pre>";
// print_r($fruits);
// echo "</pre>";

// foreach($fruits as $values){
// print_r($values);
// echo "<br>";
// }