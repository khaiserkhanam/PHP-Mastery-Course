<?php
$person = [
    "person1"=>[ "name" => "Khanam",
     "age" => 25,
     "city" => "New York"
 ],
 "person2"=>[ "name" => "Zoha",
 "age" => 27,
 "city" => "Mumbai"
 ]
 ];

//  foreach($array as $values){
    //code
//  }

// foreach($person as $values){
//     print_r($values);
//     echo "<br>";
// }


//  foreach($array as $keys=>$values){
    //code
//  }

// foreach($person as $keys=>$values){
//     echo $keys ."=>";
//     print_r($values);
//     echo "<br>";
// }


// foreach($person as $values){
//     print_r($values);
//     echo "<br>";
// }

// foreach($array as $values){
//     foreach($values as $value){
//         echo $value;
//     }
// }

// foreach($person as $values){
//     foreach($values as $value){
//         echo $value;
//     }
//     echo "<br>";
// }
// Array ( [name] => Khanam [age] => 25 [city] => New York )
// Array ( [name] => Zoha [age] => 27 [city] => Mumbai )


// foreach($person as $values){
//     foreach($values as $keys=>$value){
//         echo "$keys=>$value";
//         echo "<br>";
//     }
//     echo "<br>";
// }


// foreach($person as $lable=>$values){
//     echo $lable.":";
//     echo "<br>";
//     print_r($values);
//     foreach($values as $keys=>$value){
//         echo "$keys=>$value";
//         echo "<br>";
//     }
//     echo "<br>";
// }