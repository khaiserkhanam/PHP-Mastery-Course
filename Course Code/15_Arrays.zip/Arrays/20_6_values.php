<?php
$person=[
    "name"=>"Khanam",
    "age"=>25,
    "city"=>"New York",
];
echo "<pre>";
print_r($person);
echo "</pre>";

print_r(array_values($person));