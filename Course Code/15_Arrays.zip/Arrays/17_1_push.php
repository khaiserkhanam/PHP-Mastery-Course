<?php
$fruits = ["apple", "banana", "cherry"];
echo "<pre>";
print_r($fruits);
echo "</pre>";
array_push($fruits,"grapes");
echo "<pre>";
print_r($fruits);
echo "</pre>";

array_push($fruits,"pineapple","papaya");
echo "<pre>";
print_r($fruits);
echo "</pre>";

$fruits[]="kiwi";
echo "<pre>";
print_r($fruits);
echo "</pre>";

