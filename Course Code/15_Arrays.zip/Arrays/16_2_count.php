<?php
$fruits = ["apple", "banana", "cherry"];
// echo count($fruits);

$person=array(
    "name"=>"Khanam",
    "age"=>23,

);
echo count($person);