<?php
$fruits = [
    "apple" => 7,
    "cherry"   => 9,
    "banana" => 5,
    "elderberry" => 1,
    "date" => 2,
   
];

echo "<pre>";
print_r($fruits);
echo "</pre>";
ksort($fruits);
echo "<pre>";
print_r($fruits);
echo "</pre>";