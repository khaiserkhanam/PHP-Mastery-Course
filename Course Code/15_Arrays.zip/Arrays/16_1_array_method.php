<?php
$fruits=array("mango","apple");

$person=array(
    "name"=>"Khanam",
    "age"=>23,

);
print_r($person);
