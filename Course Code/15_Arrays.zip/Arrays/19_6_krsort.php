<?php
$fruits = [
    "apple" => 7,
    "banana" => 5,
    "cherry" => 9,
    "date" => 2,
    "elderberry" => 1
];

echo "<pre>";
print_r($fruits);
echo "</pre>";
krsort($fruits);

echo "<pre>";
print_r($fruits);
echo "</pre>";