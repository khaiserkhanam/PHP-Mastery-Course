<?php
// $myname="Khanam";
// echo $myname;

// $details=[1,"Khanam","bangalore",15000.01];
// echo $details;
// echo "<pre>";
// print_r($details);
// echo "</pre>";

// echo "<br>";
// var_dump($details);

// Access individual elements

// echo $details[0];
// echo $details[1];
// echo $details[2];
// echo $details[3];


// Inside double quotes
// print_r("$details");  // not possible
// echo "$details[0]";
// echo "$details[1]";
// echo $details[2];
// echo '$details[3]';


// Indentation.
// $details=[1,
// "Khanam",
// "bangalore",
// 15000.01
// ];
// echo "<pre>";
// print_r($details);
// echo "</pre>";

// echo "<br>";

// var_dump($details);