<?php
$person = [
    "person1"=>[ "name" => "Khanam",
     "age" => 25,
     "city" => "New York"
 ],
 "person2"=>[ "name" => "Zoha",
 "age" => 27,
 "city" => "Mumbai"
 ],
 [1,2,3]
 ];

//  echo $person;
// echo "<pre>";
// print_r($person);
// echo "</pre>";
// var_dump($person);

// echo "<br>";
// echo $person['person1'];
// print_r($person['person1']);
// echo "<br>";
// print_r($person['person2']);
// print_r($person[0]);


// echo $person['person1']['city'];
// echo $person['person2']['name'];