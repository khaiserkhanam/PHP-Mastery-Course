<?php
// PRINT ASSOCIATIVE ARRAY
/*$person=[
    "name"=>"Khanam",
    "age"=>25,
    "city"=>"New York",
    3=>340,
];
echo $person;
echo "<pre>";
print_r($person);
echo "</pre>";
*/


// ACCESS INDIVIDUAL VALUES
/*
echo $person['name'];
echo $person['age'];
echo $person['city'];
echo $person[3];
*/

// INDEXED ARRAY 
/*
$fruits=["apple","ball"];
echo "<pre>";
print_r($fruits);
echo "</pre>";
echo $fruits[0];
*/


// Only keys
/*
$person=[
    "name"=>"Khanam",
    "age"=>25,
    "city"=>"New York",
];
print_r(array_keys($person));
print_r(array_keys($person)[1]);
*/


// Only values
// print_r(array_values($person));
// print_r(array_values($person)[2]);


//ADD ELEMENTS INSIDE ARRAY
/*
$person=[
    "name"=>"Khanam",
    "age"=>25,
    "city"=>"New York",
];
echo "<pre>";
print_r($person);
echo "</pre>";
$person['role']="Data Analyst";
echo "<pre>";
print_r($person);
echo "</pre>";
var_dump($person);
*/


//SPECIFY INDEX NUMBER
/*
$person=[
    "name"=>"Khanam",
    "age"=>25,
    "city"=>"New York",
    1=>"One",
    0=>"Zero",
];

echo $person[1];
echo empty($person[1])?"Value is empty":"Value is not empty";


$person[]=["gender"=>"female"];
echo "<pre>";
print_r($person);
echo "</pre>";

$person[6]=["gender"=>"female"];
echo "<pre>";
print_r($person);
echo "</pre>";

$person[]=["gender1"=>"female1"];
echo "<pre>";
print_r($person);
echo "</pre>";

$person['gender']="Female";
echo "<pre>";
print_r($person);
echo "</pre>";
echo $person['gender'];
*/