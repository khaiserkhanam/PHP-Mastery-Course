<?php
// $bioData=["Khanam",'true',1,450,"Siya"];
// echo "<pre>";
// print_r($bioData);
// echo "</pre>";
// $reverseArray=array_reverse($bioData);
// echo "<pre>";
// print_r($reverseArray);
// echo "</pre>";

// $reverseArray=array_reverse($bioData,true);
// echo "<pre>";
// print_r($reverseArray);
// echo "</pre>";