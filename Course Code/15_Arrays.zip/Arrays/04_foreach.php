<?php
// $fruits = ["apple", "banana", "cherry","mango",1];
// echo "<pre>";
// print_r($fruits);
// echo "</pre>";

// echo "<br>";

// echo $fruits[0];
// echo "<br>";
// echo $fruits[1];
// echo "<br>";
// echo $fruits[2];
// echo "<br>";
// echo $fruits[3];
// echo "<br>";
// echo $fruits[4];
// echo "<br>";

// Syntax
// foreach($array as $values){
// Code which has to be executed
// }


// echo "<br>";
// echo "Using for each loop";
// echo "<br>";
// foreach($fruits as $values){
//     echo $values;
//     print_r($fruits);
//     echo "<br>";
// }


// Example2:
$month = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul","Aug","Sep","Oct","Nov","Dec"];

echo "<pre>";
print_r($month);
echo "</pre>";


// foreach($month as $monthData){
//     echo $monthData;
//     echo "<br>";
// }

// $counter=0;
// foreach($month as $monthData){
//     echo $month[$counter];
//     echo "<br>";
//     $counter++;
// }


// $counter=0;
// foreach($month as $monthData){
//     echo "[$counter] => $monthData";
//     echo "<br>";
//     $counter++;
// }


// $counter=0;
// foreach($month as $monthData){
//     echo "[$counter] => $month[$counter]";
//     echo "<br>";
//     $counter++;
// }
