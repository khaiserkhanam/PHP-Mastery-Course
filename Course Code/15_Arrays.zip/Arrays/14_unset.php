<?php
// $numbers=[1,2,3,4,5,6];
// echo "<pre>";
// print_r($numbers);
// echo "</pre>";

// unset($numbers[3]);
// echo "<pre>";
// print_r($numbers);
// echo "</pre>";

// $numbers[]=7;
// echo "<pre>";
// print_r($numbers);
// echo "</pre>";

// Associative array
// $person=[
//     "name"=>"Khanam",
//     "age"=>25,
//     "city"=>"New York",
// ];
// echo "<pre>";
// print_r($person);
// echo "</pre>";

// unset($person['age']);
// echo "<pre>";
// print_r($person);
// echo "</pre>";

// $person[]=90;
// echo "<pre>";
// print_r($person);
// echo "</pre>";

// $person['age']=50;
// echo "<pre>";
// print_r($person);
// echo "</pre>";

// $person[]=80;
// echo "<pre>";
// print_r($person);
// echo "</pre>";

// unset($person[0]);
// echo "<pre>";
// print_r($person);
// echo "</pre>";

// $person[]=90;
// echo "<pre>";
// print_r($person);
// echo "</pre>";