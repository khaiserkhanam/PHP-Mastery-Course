<?php
$fruits = ["apple", "banana", "cherry"];
echo "<pre>";
print_r($fruits);
echo "</pre>";
// array_pop($fruits);
// echo "<pre>";
// print_r($fruits);
// echo "</pre>";

$removedElement=array_pop($fruits);
echo "<pre>";
print_r($fruits);
echo "</pre>";
echo $removedElement;