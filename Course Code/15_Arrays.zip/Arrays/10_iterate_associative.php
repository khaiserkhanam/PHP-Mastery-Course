<?php
// ITERATE ASSOCIATIVE ARRAY
$person = [
    "name" => "Khanam",
    "age" => 25,
    "city" => "New York"
];
echo "<pre>";
print_r($person);
echo "</pre>";

// echo $person['name'] . "<br>";
// echo $person['age'] . "<br>";
// echo $person['city'] . "<br>";

// foreach($array as $values){
    //code 
// }

// foreach($person as $values){
//     echo $values;
// }


// foreach($array as $key=>$values){
    //code
// }


// foreach($person as $keys=>$values){
//     echo $keys;
//     echo $values ."<br>";
// }



// foreach($person as $keys=>$values){
//    echo $keys."=>".$values ."<br>";
// }


// foreach($person as $keys=>$values){
//  echo "$keys=>$values <br>";
// }


// foreach($person as $keyData=>$valueData){
//     echo "$keyData=>$valueData <br>";
//    }

// foreach(array_keys($person) as $keys){
//     echo "$keys";
//    }