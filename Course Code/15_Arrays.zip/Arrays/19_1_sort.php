<?php
$numbers = [4, 2, 8, 1, 5];
echo "<pre>";
print_r($numbers);
echo "</pre>";

// sort($numbers);
// echo "<pre>";
// print_r($numbers);
// echo "</pre>";

$copysort=$numbers;
sort($copysort);
echo "<pre>";
print_r($copysort);
echo "</pre>";

echo "<pre>";
print_r($numbers);
echo "</pre>";