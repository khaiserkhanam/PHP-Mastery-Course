<?php
$records = [
    ['id' => 101, 'name' => 'Khanam', 'age' => 32],
    ['id' => 102, 'name' => 'Seema', 'age' => 25],
    ['id' => 103, 'name' => 'Saniya', 'age' => 33]
];

$names=array_column($records,'name');
print_r($names);