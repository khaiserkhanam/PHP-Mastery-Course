<?php
$data1=array(1,"Khanam",true,[1,2]);
$data2=[1,"Khanam",true,[1,2]];