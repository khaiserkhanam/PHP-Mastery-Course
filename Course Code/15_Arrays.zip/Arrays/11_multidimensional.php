<?php
//MULTIDIMENSIONAL ARRAY
// [[],[],[]]

// $data=[1,2,3,4];


// Indexed in Multi
// $multidata=[
//     [1,2,3,4],
//     [5,6,7,8],
//     [9,10],
//     [11,12,13]
// ];


// Associative in Multi
$person = [
    "name" => "Khanam",
    "age" => 25,
    "city" => "New York"
];


$personData=[
    "person1"=>[
        "name" => "Khanam",
        "age" => 25,
        "city" => "New York"
    ],
    "person2"=>[
        "name" => "Seema",
        "age" => 30,
        "city" => "Bangalore"
    ],
]



// Combination of indexed and associative
$personData=[
    "person1"=>[
        "name" => "Khanam",
        "age" => 25,
        "city" => "New York"
    ],
    "person2"=>[
        "name" => "Seema",
        "age" => 30,
        "city" => "Bangalore"
    ],
    [3,5,6,7]
]
