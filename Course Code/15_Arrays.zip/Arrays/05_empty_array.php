<?php
// EMPTY ARRAY
// In PHP, an empty array refers to an array that contains no elements. It is essentially an array with a length of zero.

// $bioData=array();
// $bioData=[];
// echo $bioData; We cannot use
// print_r($bioData);
// var_dump($bioData);
// echo count($bioData);


// Check array is empty or not
// $bioData=[];
// $bioData=[1,2];
// echo empty($bioData)?"Array is empty":"Array is not empty";

// Add elements inside empty array
// $bioData=[];
// print_r($bioData);
// var_dump($bioData);
// $bioData="Khanam";
// var_dump($bioData);

// $bioData=[];
// print_r($bioData);
// var_dump($bioData);
// $bioData=["Khanam"];
// var_dump($bioData);

// $bioData[1]="Seema";
// print_r($bioData);
// $bioData[2]=["Riya"];
// echo "<br>";
// print_r($bioData);
// $bioData[2][1]="Reema";
// echo "<br>";
// print_r($bioData);

// how to reset array
// $bioData=[1,"Khanam","Reema"];
// print_r($bioData);
// $bioData=[];
// print_r($bioData);


// $bioData=[[]];
// print_r($bioData);
// var_dump($bioData);