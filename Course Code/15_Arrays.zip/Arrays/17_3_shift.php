<?php
$fruits = ["apple", "banana", "cherry"];
echo "<pre>";
print_r($fruits);
echo "</pre>";
// array_shift($fruits);
// echo "<pre>";
// print_r($fruits);
// echo "</pre>";
$removeDElement=array_shift($fruits);
echo "<pre>";
print_r($fruits);
echo "</pre>";
echo $removeDElement;