<?php
$fruits = ["apple", "banana", "cherry", "date", "elderberry"];
echo "<pre>";
print_r($fruits);
echo "</pre>";

// shuffle($fruits);
// echo "<pre>";
// print_r($fruits);
// echo "</pre>";

// echo "<pre>";
// print_r($fruits);
// echo "</pre>";

$newData=$fruits;


shuffle($newData);
echo "<pre>";
print_r($newData);
echo "</pre>";

echo "<pre>";
print_r($fruits);
echo "</pre>";