<?php
$numbers=[1,2,3,4,5,6,7,8,9,10];
// array_filter()

echo "<pre>";
print_r($numbers);
echo "</pre>";

// Print Even numbers

// function evenNumbers($values){
//     return $values%2==0;
// }
// $evenNumbers=array_filter($numbers,'evenNumbers');

// echo "<pre>";
// print_r($evenNumbers);
// echo "</pre>";

// echo "<pre>";
// print_r($numbers);
// echo "</pre>";


// Example 2: Print odd number

// function evenNumbers($values){
//     return $values%2!==0;
// }
// $evenNumbers=array_filter($numbers,'evenNumbers');

// echo "<pre>";
// print_r($evenNumbers);
// echo "</pre>";

// function evenNumbers($values){
//     return $values%2!==0;
// }
// $evenNumbers=array_filter($numbers,function ($values){
//     return $values%2!==0;
// });

// echo "<pre>";
// print_r($evenNumbers);
// echo "</pre>";