<?php
$fruits = ["apple", "banana", "cherry", "date", "elderberry"];

echo in_array("apple",$fruits)?"element is present":"Element is not present";
echo in_array("pineapple",$fruits)?"element is present":"Element is not present";