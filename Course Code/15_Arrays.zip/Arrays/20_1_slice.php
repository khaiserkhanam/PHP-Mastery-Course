<?php
$fruits = ["apple", "banana", "cherry", "pineapple", "grapes"];
echo "<pre>";
print_r($fruits);
echo "</pre>";

// $slicedData=array_slice($fruits,1);
// echo "<pre>";
// print_r($slicedData);
// echo "</pre>";

// $slicedData=array_slice($fruits,1,1);
// echo "<pre>";
// print_r($slicedData);
// echo "</pre>";

// $slicedData=array_slice($fruits,1,1,true);
// echo "<pre>";
// print_r($slicedData);
// echo "</pre>";