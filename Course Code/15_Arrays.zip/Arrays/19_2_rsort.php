<?php

$numbers = [4, 2, 8, 1, 5];
echo "<pre>";
print_r($numbers);
echo "</pre>";
rsort($numbers);
echo "<pre>";
print_r($numbers);
echo "</pre>";