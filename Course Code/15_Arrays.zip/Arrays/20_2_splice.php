<?php
$fruits = ["apple", "banana", "cherry", "pineapple", "grapes"];
echo "<pre>";
print_r($fruits);
echo "</pre>";
$removedElement=array_splice($fruits,2,2,["mango","papaya"]);

echo "<pre>";
print_r($fruits);
echo "</pre>";

echo "<pre>";
print_r($removedElement);
echo "</pre>";