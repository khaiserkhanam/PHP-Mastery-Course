<?php
// $fruits = [
//     "apple" => 7,
//     "banana" => 5,
//     "cherry" => 9,
//     "date" => 2,
//     "elderberry" => 1
// ];

$fruits = [
   1 => "apple",
    2 => "cherry",
   3 =>"banana" ,
    4 => "elderberry",
    5 => "date"
];


echo "<pre>";
print_r($fruits);
echo "</pre>";

asort($fruits);
echo "<pre>";
print_r($fruits);
echo "</pre>";