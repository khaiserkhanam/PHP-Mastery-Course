<?php
$person=[
    "name"=>"Khanam",
    "age"=>25,
    "city"=>"New York",
];
echo "<pre>";
print_r($person);
echo "</pre>";

// echo array_keys($person);
print_r(array_keys($person));