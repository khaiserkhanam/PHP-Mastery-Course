<?php

$fruits = ["apple" => 5, "banana" => 2, "cherry" => 8, "grapes" => 1,1=>"One"];
echo "<pre>";
print_r($fruits);
echo "</pre>";

// echo array_key_exists("grapes",$fruits);
// echo array_key_exists(1,$fruits);
// echo array_key_exists("stawberry",$fruits)?"Key is present":"Key is not present";


if(isset($fruits['stawberry'])){
    echo "Key is present";
}else{
    echo "Key is not present";
}

