<?php
// $numbers=[1,2,3,4,5];
// array_map()
// echo "<pre>";
// print_r($numbers);
// echo "</pre>";

// function squareNumbers($values){
// return $values*$values;
// }

// $squareNumber=array_map('squareNumbers',$numbers);
// echo "<pre>";
// print_r($squareNumber);
// echo "</pre>";
// echo "<pre>";
// print_r($numbers);
// echo "</pre>";


// Example2
// function squareNumbers($values){
//     return $values*$values;
//     }
    
//     $squareNumber=array_map(function ($values){
//         return $values*$values*$values;
//         }
//         ,$numbers);

//         echo "<pre>";
// print_r($squareNumber);
// echo "</pre>";