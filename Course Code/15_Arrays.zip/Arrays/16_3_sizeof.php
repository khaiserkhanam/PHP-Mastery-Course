<?php
$fruits = ["apple", "banana", "cherry"];
echo sizeof($fruits);