<?php
$fruits = ["apple", "banana", "cherry"];
echo "<pre>";
print_r($fruits);
echo "</pre>";

array_unshift($fruits,"grapes");
echo "<pre>";
print_r($fruits);
echo "</pre>";

array_unshift($fruits,"pineapple","mango");
echo "<pre>";
print_r($fruits);
echo "</pre>";

