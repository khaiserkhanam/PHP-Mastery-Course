<?php
// MIXED ARRAYS
$bioData=["Khanam",26,true,350.01];
$bioData=[];
print_r($bioData);
// $biodata=["Khanam"];
// $bioData[0]="Khanam";
// $bioData[1]=26;
// $bioData[2]=true;
// $bioData[3]=350.01;
// print_r($bioData);


// $bioData[0]="Khanam";
// $bioData[4]=26;
// $bioData[6]=true;
// $bioData[9]=350.01;
// print_r($bioData);

// echo $bioData[1];
// echo empty($bioData[1])?"True":"False";
// $bioData[]="Seema";
// print_r($bioData);