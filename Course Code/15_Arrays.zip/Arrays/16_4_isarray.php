<?php
$fruits = ["apple", "banana", "cherry"];
$myName="Riya";
echo is_array($fruits)?"It is an array":"It is not an array";
echo is_array($myName)?"It is an array":"It is not an array";