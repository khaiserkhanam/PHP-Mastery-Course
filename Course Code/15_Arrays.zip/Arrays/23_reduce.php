<?php
$numbers=[1,2,3,4,5,6,7,8,9,10];
echo "<pre>";
print_r($numbers);
echo "</pre>";
// function addfirstNumbers($acc,$value){
//   return $acc+$value;
// }
// $addNumbers=array_reduce($numbers,'addfirstNumbers',0);
// echo "<pre>";
// print_r($addNumbers);
// echo "</pre>";

// $addNumbers=array_reduce($numbers,'addfirstNumbers');
// echo "<pre>";
// print_r($addNumbers);
// echo "</pre>";

// $numData=[1,2,3,4,5];
// $factorial=array_reduce($numData,'factorialNumber',1);
// function factorialNumber($acc,$value){
//     return $acc*$value;
// }
// echo "<pre>";
// print_r($factorial);
// echo "</pre>";