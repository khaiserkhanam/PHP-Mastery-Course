<?php
$data1=["Khanam","Seema","Riya"];
$data2=["Seeta","Reema"];
echo "<pre>";
print_r($data1);
echo "</pre>";
echo "<pre>";
print_r($data2);
echo "</pre>";
// $mergeData=array_merge($data1,$data2);

// echo "<pre>";
// print_r($mergeData);
// echo "</pre>";

$mergeData=array_merge($data2,$data1);

echo "<pre>";
print_r($mergeData);
echo "</pre>";



$array1 = ["a" => "apple", "b" => "banana"];
$array2 = ["b" => "blueberry", "c" => "cherry"];

echo "<pre>";
print_r($array1);
echo "</pre>";

echo "<pre>";
print_r($array2);
echo "</pre>";

// $merge=array_merge($array1,$array2);
// echo "<pre>";
// print_r($merge);
// echo "</pre>";

$merge=array_merge($array2,$array1);
echo "<pre>";
print_r($merge);
echo "</pre>";