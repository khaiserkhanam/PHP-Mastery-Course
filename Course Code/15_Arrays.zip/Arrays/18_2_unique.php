<?php
$fruits = ["apple", "banana", "cherry", "banana", "date", "cherry", "elderberry"];
echo "<pre>";
print_r($fruits);
echo "</pre>";
$uniqueArray=array_unique($fruits);
echo "<pre>";
print_r($uniqueArray);
echo "</pre>";

$valuesData=array_values($uniqueArray);
echo "<pre>";
print_r($valuesData);
echo "</pre>";