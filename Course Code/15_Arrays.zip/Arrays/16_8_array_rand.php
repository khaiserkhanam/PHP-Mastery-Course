<?php
$fruits = ["apple", "banana", "cherry", "date", "elderberry"];
// $randomKey=array_rand($fruits);
// echo $randomKey;
// echo $fruits[$randomKey];

$randomKey=array_rand($fruits,3);
print_r($randomKey);

foreach($randomKey as $values){
   echo $fruits[$values];
}