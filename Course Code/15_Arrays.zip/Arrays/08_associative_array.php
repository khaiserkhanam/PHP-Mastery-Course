<!-- index=>value
key=>value -->
<?php
// $person=[
//     0=>"Seema",
//     1=>"Khanam",
//    5=>340,
//     9=>true

// ];


// $person=[
//     "name1"=>"Seema",
//     "name2"=>"Khanam",
//    "salary"=>340,
//     "login"=>true

// ];