<?php
// $percentage=89.01;
// var_dump($percentage);
// $percentage=-89.01;
// var_dump($percentage);

// $data=89.5;
// var_dump($data);
// $roundData= round($data);
// var_dump($roundData);
