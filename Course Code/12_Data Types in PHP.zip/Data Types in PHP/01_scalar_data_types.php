<?php
// $data='1','2','22';
// echo $data;


// $names=true,false;
// echo $names;
