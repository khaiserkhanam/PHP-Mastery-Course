<?php

// $numberArray=array(1,2,'3',4,5,true,null);
// echo "<pre>";
// var_dump($numberArray);
// echo "</pre>";
// print_r($numberArray);
// print_r($numberArray[3]);

// $fruits=['mango','apple'];
// print_r($fruits[1]);