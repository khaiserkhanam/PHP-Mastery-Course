<?php

class Fruit{
    public $color;

    public function cutPieces(){
        echo "Cut 2 pieces";
    }
}

$apple= new Fruit();
var_dump($apple);
$apple->color="Red";
echo $apple->color;
var_dump($apple);
$apple->cutPieces();


