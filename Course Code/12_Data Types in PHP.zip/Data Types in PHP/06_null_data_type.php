<?php
// $myname="Khanam";
// echo var_dump($myname);

// $age=null;
// $age='0';
// echo $age;
// echo var_dump($age);

// echo ($age)?"It has value":"It doesn't have value";


// is_null()
// echo is_null($age);  //1
// echo (is_null($age))?"It doesn't have value":"It has value";
// echo (!is_null($age))?"It has value":"It doesn't have value";


// unset();
// $subject="PHP";
// echo $subject;
// unset($subject);
// echo $subject;