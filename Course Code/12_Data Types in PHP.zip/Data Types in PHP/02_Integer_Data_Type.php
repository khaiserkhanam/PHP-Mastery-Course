<?php
    /*
     1)Integers are whole numbers
     2)Integers can have positive as well as negative values
     2)Integer Variable can hold Octal (base 8), Hexadecimal(base 16) and Binary (base 2) Values.
     */

     
// $age=18;
// $age=18/7;
// echo $age;
// echo var_dump($age);

// $age=-18;
// echo $age;
// echo var_dump($age);

// $data=0x160A93F;
// echo $data;
// echo var_dump($data);

// echo PHP_INT_MAX;
// $x=9223372036854775845;
// echo $x;

// echo PHP_INT_SIZE;