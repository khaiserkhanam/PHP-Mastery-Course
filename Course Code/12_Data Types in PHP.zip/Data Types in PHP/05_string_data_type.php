<?php
// $name1="Khanam";
// $name2='Saniya';

// echo $name1;
// echo '$name2';

// $data= $name1. $name2;
// echo $data;

// echo $name1.$name2;
// echo $name1."-".$name2;
// echo "$name1-$name2";


// echo "PHP is backend \"programming\" language";
// echo "\t\t\tPHP is backend \"programming\" language";
// echo '\t\t\tPHP is backend \"programming\" language';
// echo "\TPHP is backend \"programming\" language";

// $subject=" PHP";
// echo $subject;
// echo strlen($subject);



$num1="5";
var_dump($num1);
$num2=10;
var_dump($num2);
$data= $num1*$num2;
echo $data;
var_dump($data);