<?php
// declare(strict_types=1);
// function sum(int $a,int $b):int{
    // echo $a+$b;
//     return $a+$b;
// }
// sum('10','4');
// $d=sum(10,8);
// echo $d;


// function sum(string $a,string $b):string{
    // echo $a+$b;
//     return $a.$b;
// }
// sum('10','4');
// $d=sum(8,"Khanam");
// echo $d;


