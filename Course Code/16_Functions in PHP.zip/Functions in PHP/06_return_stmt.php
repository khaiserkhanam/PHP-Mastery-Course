<?php
// function sum( $a, $b){
// echo $a+$b;
     //return $a+$b;  //value

    
// }
// $result=sum(9,7);
// echo $result;

// function sum( $a, $b){
//      $count=$a+$b;
//      return $count;
    
// }
// $result=sum(9,7);
// echo $result;

// function sum( $a, $b){
//      $count=$a+$b;
//      echo "Hello";
//      return $a+$b."Khanam";
//      return $count;
// }
// $result=sum(9,5);
// echo $result;


// function sum( int $a,int $b):string{
//     $count=$a+$b;
//     echo "Hello";
//     return $a+$b."Khanam";
//     return $count;
// }
// $result=sum(9,5);
// echo $result;