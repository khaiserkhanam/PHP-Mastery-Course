<?php
// function display_names($firstName,$lastName){
//     echo "$firstName $lastName";
// }
// display_names('Khaiser','Khanam');
// display_names('Riya','Mehta');



// Find sum of two number
// function sum($a,$b){
//     echo $a+$b;
// }
// $firstValue=15;
// $secondValue=30;
// sum($firstValue,$secondValue);

// sum('9','1');