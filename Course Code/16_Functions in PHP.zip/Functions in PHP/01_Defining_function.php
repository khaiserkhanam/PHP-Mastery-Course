<?php
// Define and Call a function

function display_message(){
    echo "Hello Zoha";
echo "<br>";
echo "Welcome to website";
}


display_message();
display_message();
display_message();
display_message();
display_message();
display_message();
display_message();
display_message();

