<?php

function iceCups($ice){
return $ice*2;
}

function iceCreamMachine($chocolate, $vanilla,$pineapple){
    $chocolateCups=iceCups($chocolate);
    $vanillaCups=iceCups($vanilla);
    $pineAppleCups=iceCups($pineapple);
    $result="My chocolate cups $chocolateCups, my vanilla cups  $vanillaCups and my pineapple cups $pineAppleCups";
    return $result;
}
$ice1=iceCreamMachine(2,3,6);
echo $ice1;