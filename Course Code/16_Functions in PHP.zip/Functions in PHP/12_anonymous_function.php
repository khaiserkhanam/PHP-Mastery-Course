<?php
// Anonymous Function
/*
The function which does not have a function name, they don't have any name to it.
This is basically defining the function without a function name and assigning to a variable. So variable actually holds a function. 
*/


// function friend(){
//     echo "My friend is Khanam";
// }
// friend();

// Anonymous Function
// $displayFriend=function(){
//     echo "My friend is Khanam";
// };
// $displayFriend();



// ACCESS PARENT SCOPE VARIABLE INSIDE ANONYMOUS FUNCTION
// $myList="List is completed";
// function data(){
//     echo $myList;
// }
// data();

// $myList="List is completed";
// function data() use($myList){
//     echo $myList;
// }
// data();


// $accessData=function(){
//     echo $myList;
// };
// $accessData();


// $accessData=function() use($myList){
//     echo $myList;
// };
// $accessData();



