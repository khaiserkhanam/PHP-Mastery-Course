<?php
// Dynamic function calling. 
/*Dynamic function calling in PHP allows you to call functions whose names are determined at runtime. This is useful when you have multiple functions that serve similar purposes, and you want to decide which one to call based on certain conditions or parameters.*/


// function myName(){
//     echo "Khanam";
// }
// myName();

// function myName(){
//     echo "Khanam";
// }
// $displayName="myName";
// echo $displayName;
// echo $displayName();  //myName();


// function myName($name){
//     echo $name;
// }
// $displayName="myName";
// echo $displayName;
// echo $displayName("Riya Mehta");  //myName(arguments);


// function greet(){
//     echo "Good morning";
// }

// function farewell(){
//     echo "Good Bye";
// }

// $condition=false;
// if($condition){
//     $functionName='greet';
// }else{
//     $functionName='farewell';
// }
// $functionName();

// Create a function to add 2 numbers