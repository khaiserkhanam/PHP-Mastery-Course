<!-- Find area and perimeter of rectangle -->
<?php

// Function to calculate area of rectangle
function calculateRectangleArea($length,$breadth){
    return $length*$breadth;
}

// Function to calculate perimeter of rectangle
function calculateRectanglePerimeter($length,$breadth){
    return 2*($length+$breadth);
}


// function to display area and perimeter of rectangle
function displayRectangleDetails($length,$breadth){
    $area=calculateRectangleArea($length,$breadth);
    $perimeter=calculateRectanglePerimeter($length,$breadth);

    echo "Rectangle Details<br>";
    echo "Length:$length<br>";
    echo "Breadth:$breadth<br>";
    echo "Area:$area<br>";
    echo "Perimeter:$perimeter<br> ";
}
displayRectangleDetails(5,3);