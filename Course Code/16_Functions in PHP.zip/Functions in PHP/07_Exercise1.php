<?php
// Find totalmarks and percentage

function marks($maths,$science,$social,$english,$hindi,$kannada){
    $sum=$maths+$science+$social+$english+$hindi+$kannada;
    return $sum;
}
$totalMarks=marks(95,91,98,67,56,78);
// echo $totalMarks;

function percentage($total){
 $subject=6;
 $percentage=$total/$subject;
 return $percentage;
}

$studentPercentage=percentage($totalMarks);
echo $studentPercentage ."%";