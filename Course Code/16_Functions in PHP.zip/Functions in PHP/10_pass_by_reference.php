<?php
// PASS BY VALUE
// function greet($msg){
//     $msg="Good morning";
    // echo $msg;
// }
// $message="Hey";
// greet($message);
// echo $message;


// PASS BY REFERENCE
// function greet(&$msg){
//     $msg="Good morning";
    // echo $msg;
// }
// $message="Hey";
// greet($message);
// echo $message;

// PASS BY VALUE
// function increment($num){
//     $num++;
//     echo "Inside function $num<br>";
// }
// $value=10;
// echo "Before function call $value<br>";
// increment($value);
// echo "After function call $value<br>";

// PASS BY REFERENCE
// function increment(&$num){
//     $num++;
//     echo "Inside function $num<br>";
// }
// $value=10;
// echo "Before function call $value<br>";
// increment($value);
// echo "After function call $value<br>";