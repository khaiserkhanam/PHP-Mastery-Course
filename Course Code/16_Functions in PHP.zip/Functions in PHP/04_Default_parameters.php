<?php
// Default/ Optional parameters

// function myName($name="Khanam"){
//     echo "$name";
// }
// myName("Saniya");
// myName();


// Find sum of two number
// function sum($a=1,$b=6){
//     echo $a+$b;
// }
// sum(10);
// sum(10,4);
// sum(1,6);

