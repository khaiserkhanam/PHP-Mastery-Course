<?php
include '01_connect.php';


$fetch_records=$con->query("Select * from employee_data");



// while($row=$fetch_records->fetch(PDO::FETCH_ASSOC)){
//    echo $row['emp_id'];
//    echo $row['emp_name'];
//    echo $row['emp_place'];
//    echo $row['emp_age'];
//    echo $row['emp_dob'];
//    echo "<br>";
// }



// while($row=$fetch_records->fetchAll()){
//    echo "<pre>";
//    print_r($row);
//    echo "</pre>";
//  }
 

// $row=$fetch_records->fetchAll();
//     echo "<pre>";
//     print_r($row);
//     echo "</pre>";



// $row=$fetch_records->fetchAll(PDO::FETCH_ASSOC);
//     echo "<pre>";
//     print_r($row);
//     echo "</pre>";

    // echo $row[0]['emp_name'];
  

    // $row=$fetch_records->fetchAll(PDO::FETCH_NUM);
    // echo "<pre>";
    // print_r($row);
    // echo "</pre>";
    // echo $row[0][2];


    // $row=$fetch_records->fetchAll(PDO::FETCH_BOTH);
    // echo "<pre>";
    // print_r($row);
    // echo "</pre>";


    // $row=$fetch_records->fetchAll(PDO::FETCH_OBJ);
    // echo "<pre>";
    // print_r($row);
    // echo "</pre>";

    // echo $row[0]->emp_dob;
