<?php
include '01_connect.php';


$fetch_records=$con->query("Select * from employee_data");


// PDO::FETCH_ASSOC
/*while($row=$fetch_records->fetch(PDO::FETCH_ASSOC)){
   echo $row['emp_id'];
   echo $row['emp_name'];
   echo $row['emp_place'];
   echo $row['emp_age'];
   echo $row['emp_dob'];
   echo "<br>";
}
*/


// PDO::FETCH_NUM
/*
while($row=$fetch_records->fetch(PDO::FETCH_NUM)){
    echo $row[0];
    echo $row[1];
    echo $row[2];
    echo $row[3];
    echo $row[4];
    echo "<br>";
    
}
*/



// PDO::FETCH_BOTH
/*
while($row=$fetch_records->fetch(PDO::FETCH_BOTH)){
    echo $row[0];
    echo $row[1];
    echo $row[2];
    echo $row[3];
    echo $row[4];
    echo "<br>";
    echo $row['emp_id'];
    echo $row['emp_name'];
    echo $row['emp_place'];
    echo $row['emp_age'];
    echo $row['emp_dob'];
    echo "<br>";
}
*/



// PDO::FETCH_OBJ
/*
while($row=$fetch_records->fetch(PDO::FETCH_OBJ)){
    echo $row->emp_id;
    echo $row->emp_name;
    echo $row->emp_place;
    echo $row->emp_age;
    echo $row->emp_dob;
    echo "<br>";
}
*/