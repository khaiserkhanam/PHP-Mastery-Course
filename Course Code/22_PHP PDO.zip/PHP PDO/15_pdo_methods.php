<?php
include '01_connect.php';
$con->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_ASSOC);

// $fetch_records=$con->prepare("Select * from employee_data where emp_place='Bengaluru'");
// $fetch_records->execute();
// echo $fetch_records->rowCount();

// $row=$fetch_records->fetchAll();
// echo "<pre>";
// print_r($row);
// echo "</pre>";


// $empName="Suman";
// $place="Chennai";
// $age=35;
// $dob=1989;


// $insert_query=$con->prepare('Insert into employee_data (emp_name,emp_place,emp_age,emp_dob) values (:emp_name, :emp_place , :emp_age, :emp_dob)');

// $insert_query->execute([':emp_name'=>$empName , ':emp_place'=> $place , ':emp_age'=>$age , ':emp_dob'=>$dob]);
// echo $con->lastInsertId();


// exec() 

// $fetch_records="Update employee_data set emp_place='Kolkata' where emp_name='Suresh'";
// $result=$con->exec($fetch_records);
// echo $result;
// $row=$fetch_records->fetchAll();
// echo "<pre>";
// print_r($row);
// echo "</pre>";