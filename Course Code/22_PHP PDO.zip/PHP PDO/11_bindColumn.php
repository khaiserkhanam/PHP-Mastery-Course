<?php
include '01_connect.php';
$con->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_ASSOC);

// $place='Bengaluru';
// $fetch_records=$con->prepare("Select * from employee_data where emp_place=?");
// $fetch_records->bindParam(1,$place,PDO::PARAM_STR);
// $fetch_records->execute();

// $row=$fetch_records->fetchAll();
// echo "<pre>";
// print_r($row);
// echo "</pre>";

/******************************************/
// $fetch_records=$con->prepare("Select emp_name,emp_place,emp_age from employee_data");
// $fetch_records->bindColumn('emp_name',$username);
// $fetch_records->bindColumn('emp_place',$place);
// $fetch_records->bindColumn('emp_age',$age);
// $fetch_records->execute();

// $row=$fetch_records->fetchAll();
// echo "<pre>";
// print_r($row);
// echo "</pre>";


// echo $row[0]['emp_name'];
// echo $username;

// while($row=$fetch_records->fetch()){
//     echo $username;
//     echo "<br>";
// }

/******************************************/
// EXAMPLE2
// $fetch_records=$con->prepare("Select emp_name,emp_place,emp_age from employee_data");
// $fetch_records->bindColumn(1,$username);
// $fetch_records->bindColumn(2,$place);
// $fetch_records->bindColumn(3,$age);
// $fetch_records->execute();

// while($row=$fetch_records->fetch()){
//     echo $place;
//     echo "<br>";
// }