<?php
include '01_connect.php';
$con->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_ASSOC);




// $place='Bengaluru';
// $fetch_records=$con->prepare("Select * from employee_data where emp_place=?");
// $fetch_records->bindParam(1,$place,PDO::PARAM_STR);
// $fetch_records->execute();

// $row=$fetch_records->fetchAll();
// echo "<pre>";
// print_r($row);
// echo "</pre>";


// $place='Bengaluru';
// $fetch_records=$con->prepare("Select * from employee_data where emp_place=?");
// $fetch_records->bindValue(1,'Bengaluru',PDO::PARAM_STR);
// $fetch_records->execute();

// $row=$fetch_records->fetchAll();
// echo "<pre>";
// print_r($row);
// echo "</pre>";



// $place='Bengaluru';
// $fetch_records=$con->prepare("Select * from employee_data where emp_place=?");
// $fetch_records->bindParam(1,'Bengaluru',PDO::PARAM_STR);
// $fetch_records->execute();

// $row=$fetch_records->fetchAll();
// echo "<pre>";
// print_r($row);
// echo "</pre>";



// $place='Bengaluru';
// $fetch_records=$con->prepare("Select * from employee_data where emp_place=?");
// $fetch_records->execute(array($place));

// $row=$fetch_records->fetchAll();
// echo "<pre>";
// print_r($row);
// echo "</pre>";


// $place='Bengaluru';
// $fetch_records=$con->prepare("Select * from employee_data where emp_place=?");
// $fetch_records->execute([$place]);

// $row=$fetch_records->fetchAll();
// echo "<pre>";
// print_r($row);
// echo "</pre>";


// $place='Bengaluru';
// $myname="Khanam";
// $fetch_records=$con->prepare("Select * from employee_data where emp_place=? and emp_name=?");
// $fetch_records->execute([$place,$myname]);

// $row=$fetch_records->fetchAll();
// echo "<pre>";
// print_r($row);
// echo "</pre>";