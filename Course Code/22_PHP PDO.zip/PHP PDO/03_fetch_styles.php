<?php
include '01_connect.php';


$fetch_records=$con->query("Select * from employee_data");

// while($row=$fetch_records->fetch()){
//     echo "<pre>";
//     print_r($row);
//     echo "</pre>";
// }



// PDO::FETCH_ASSOC
/*while($row=$fetch_records->fetch(PDO::FETCH_ASSOC)){
    echo "<pre>";
    print_r($row);
    echo "</pre>";
}
*/



// PDO::FETCH_NUM
/*
while($row=$fetch_records->fetch(PDO::FETCH_NUM)){
    echo "<pre>";
    print_r($row);
    echo "</pre>";
}
*/


// PDO::FETCH_BOTH
/*
while($row=$fetch_records->fetch(PDO::FETCH_BOTH)){
    echo "<pre>";
    print_r($row);
    echo "</pre>";
}
*/


// PDO::FETCH_OBJ

/*
while($row=$fetch_records->fetch(PDO::FETCH_OBJ)){
    echo "<pre>";
    print_r($row);
    echo "</pre>";
}
*/