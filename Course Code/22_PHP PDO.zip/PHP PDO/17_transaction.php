<?php
try{
$db_name="mysql:host=localhost;dbname=pdo_tutorial";
$username="root";
$password='';

$con=new PDO($db_name,$username,$password);

$con->beginTransaction();
// Insert query
$insert=$con->prepare("Insert into users (username, email) values (?,?)");
// Update query
$update=$con->prepare("update account_balance set balance=balance-50 where id=?");

$insert->execute(["Suman","suman@gmail.com"]);
$update->execute([2]);

$con->commit();
echo "Transaction successful";

}catch(Exception $e){
    $con->rollback();
    echo "Transaction got failed".$e->getMessage();
}