<?php
try{
$db_name="mysql:host=localhost;dbname=pdo_tutorial";
$username="root";
$password='';
$options=[PDO::ATTR_DEFAULT_FETCH_MODE =>PDO::FETCH_ASSOC , PDO::ATTR_ERRMODE=> PDO::ERRMODE_EXCEPTION];

$con=new PDO($db_name,$username,$password,$options);
// $con->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_ASSOC);

// $con->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

$fetch_records=$con->query("Select * from employee_data");
$row=$fetch_records->fetchAll();
    echo "<pre>";
    print_r($row);
    echo "</pre>";


}catch(PDOException $e){
    echo $e->getMessage();
}