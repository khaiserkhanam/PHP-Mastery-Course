<?php
include '01_connect.php';
$con->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_NUM);

$fetch_records=$con->query("Select * from employee_data");


// PDO::FETCH_ASSOC
while($row=$fetch_records->fetch()){
   echo $row[0];
   echo $row[1];
   echo $row[2];
   echo $row[3];
   echo $row[4];
   echo "<br>";
}
