<?php
$db_name="mysql:host=localhost;dbname=pdo_tutorial";
$username="root";
$password='';

$con=new PDO($db_name,$username,$password);
// $con=new PDO("mysql:host=localhost;dbname=pdo_tutorial","root","");
if(!$con){
    echo "Connection is not successful";
}