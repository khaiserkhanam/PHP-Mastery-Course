<?php
include '01_connect.php';


// $fetch_records=$con->query("Select * from employee_data");

// SINGLE RECORD

/* $row=$fetch_records->fetch();
echo "<pre>";
print_r($row);
echo "</pre>";
*/


// MULTIPLE RECORDS
/*
while($row=$fetch_records->fetch()){
    echo "<pre>";
    print_r($row);
    echo "</pre>";
}
*/