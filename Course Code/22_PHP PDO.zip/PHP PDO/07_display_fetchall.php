<?php
include '01_connect.php';
$con->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_ASSOC);

$fetch_records=$con->query("Select * from employee_data");

/*$row=$fetch_records->fetchAll();
if(count($row)>0){
    echo "<pre>";
    print_r($row);
    echo "</pre>";
}else{
    echo "No records found";
}
*/

/*$row=$fetch_records->fetchAll();
if(count($row)){
    echo "<pre>";
    print_r($row);
    echo "</pre>";
}else{
    echo "No records found";
}
*/

/*$row=$fetch_records->fetchAll();
if(count($row)){
    foreach($row as $value){
            echo "<pre>";
    print_r($value);
    echo "</pre>";
        echo "<br>";
        foreach($value as $data){
            echo $data;
            echo "<br>";
        }
    }
}else{
    echo "No records found";
}
*/