<?php
include '01_connect.php';
$con->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_ASSOC);


$place='Mumbai';
$id=2;
$fetch_records=$con->prepare("Select * from employee_data where emp_place=? or emp_id>=?");
$fetch_records->bindParam(1,$place,PDO::PARAM_STR);
$fetch_records->bindParam(2,$id,PDO::PARAM_INT);
$fetch_records->execute();

$row=$fetch_records->fetchAll();
echo "<pre>";
print_r($row);
echo "</pre>";