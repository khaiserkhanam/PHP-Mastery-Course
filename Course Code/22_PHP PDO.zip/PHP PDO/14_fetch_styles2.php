<?php
include '01_connect.php';
// $con->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_ASSOC);


// $fetch_records=$con->prepare("Select * from employee_data");
// $fetch_records->execute();

// $row=$fetch_records->fetchAll(PDO::FETCH_COLUMN);
// echo "<pre>";
// print_r($row);
// echo "</pre>";


// $fetch_records=$con->prepare("Select * from employee_data");
// $fetch_records->execute();

// $row=$fetch_records->fetchAll(PDO::FETCH_COLUMN,3);
// echo "<pre>";
// print_r($row);
// echo "</pre>";


// $fetch_records=$con->prepare("Select emp_place,emp_name from employee_data");
// $fetch_records->execute();

// $row=$fetch_records->fetchAll(PDO::FETCH_GROUP);
// echo "<pre>";
// print_r($row);
// echo "</pre>";


// $fetch_records=$con->prepare("Select emp_place,emp_name from employee_data");
// $fetch_records->execute();

// $row=$fetch_records->fetchAll(PDO::FETCH_UNIQUE C);
// echo "<pre>";
// print_r($row);
// echo "</pre>";


// $fetch_records=$con->prepare("Select emp_place,emp_name from employee_data");
// $fetch_records->execute();

// $row=$fetch_records->fetchAll(PDO::FETCH_UNIQUE | PDO::FETCH_ASSOC);
// echo "<pre>";
// print_r($row);
// echo "</pre>";



// $fetch_records=$con->prepare("Select emp_place,emp_name from employee_data");
// $fetch_records->execute();

// $row=$fetch_records->fetchAll(PDO::FETCH_KEY_PAIR);
// echo "<pre>";
// print_r($row);
// echo "</pre>";



// $fetch_records=$con->prepare("Select emp_place,emp_name from employee_data");
// $fetch_records->execute();

// $row=$fetch_records->fetchAll(PDO::FETCH_CLASS);
// echo "<pre>";
// print_r($row);
// echo "</pre>";