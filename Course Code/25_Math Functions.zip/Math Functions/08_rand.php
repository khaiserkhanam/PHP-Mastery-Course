<?php

echo rand();
echo "<br>";
echo rand(10,100);
echo "<br>";
echo mt_rand(20,50);