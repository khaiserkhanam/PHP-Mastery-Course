<?php

// pow(x,y);

echo pow(2,3);
echo pow(3,3);