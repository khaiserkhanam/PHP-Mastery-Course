<?php

echo ceil(2.1);
echo ceil(2.5);
echo ceil(-4.6);