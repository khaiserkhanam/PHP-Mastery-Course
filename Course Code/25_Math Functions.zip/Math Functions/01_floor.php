<?php

echo floor(2.1);
echo floor(2.5);
echo floor(-4.6);