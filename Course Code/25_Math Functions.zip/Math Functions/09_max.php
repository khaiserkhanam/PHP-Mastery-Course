<?php

echo max(2,6,8,10);
echo "<br>";
$numbers=[10,90,67,100,200,16];
echo max($numbers);