<?php


echo getrandmax();
echo getrandmax();