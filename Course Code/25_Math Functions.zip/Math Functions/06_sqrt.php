<?php

echo sqrt(4);
echo sqrt(100);