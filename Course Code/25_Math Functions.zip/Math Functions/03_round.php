<?php
echo round(2.1);
echo round(2.5);
echo round(-4.6);