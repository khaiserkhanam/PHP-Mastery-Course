<?php
echo min(2,6,8,10);
echo "<br>";
$numbers=[10,90,67,100,1,200,16];
echo min($numbers);