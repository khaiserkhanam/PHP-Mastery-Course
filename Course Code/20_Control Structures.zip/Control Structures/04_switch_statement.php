<?php
$isLogin="Khanam";
// true;
// 1
// false;
// 0;
// switch($isLogin){
//     case true:
//         echo "User is loggedin";
//         break;
//     case false:
//         echo "User is not loggedin";
//         break;
//     default:
//     echo "Default value";
// }

// switch($isLogin){
//     case true:
//         echo "User is loggedin";
//     case false:
//         echo "User is not loggedin";
//     default:
//     echo "Default value";
// }


// $day=8;
// switch($day){
//     case 1:
//         echo "Sunday";
//         break;
//     case 2:
//         echo "Monday";
//         break;
//     case 3:
//         echo "Tuesday";
//         break;
//     case 4:
//         echo "Wednesday";
//         break;
//     case 5:
//         echo "Thursday";
//         break;
//     case 6:
//         echo "Friday";
//         break;
//     case 7:
//         echo "Saturday";
//         break;
//     default:
//     echo "Invalid day";
    
// }


// $day=3;
// switch($day){
//     case 1:
//         echo "Sunday";
//         echo "Saturday";
//         break;
//     case 2:
//         echo "Monday";
//         echo "Tuesday";
//         echo "Wednesday";
//         echo "Thursday";
//         echo "Friday";
//         break;
//     default:
//     echo "Invalid day";
    
// }


$weekday="Tue";
switch($weekday){
    case "Mon":
        echo "Monday";
        break;
    case "Fri":
        echo "Friday";
        break;
        default:
        echo 'Invalid selection';
}


// Exercise
    //Check if input_number is greater than 10
    // if( $input_number  > 10 ) {
    //     echo 'Number greater than 10';
    // } elseif ( $input_number  == 10 ){
    //     echo 'Number equal than 10' ;
    // } else {
    //     echo 'Number less than 10';
    // }
