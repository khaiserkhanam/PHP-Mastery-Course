<?php
// if(true){
//     echo "Hello Khanam";
// }

// if(false){
//     echo "Hello Khanam";
// }

// $username="Khanam";
// if($username){
//     echo "Welcome $username";
// }

// $username="Khanam";
// if(isset($username)){
//     echo "Welcome $username";
// }


// if(10<20){
//     echo "Yes it is";
// }

// if(10>20){
//     echo "Yes it is";
// }
// echo "Iam done";