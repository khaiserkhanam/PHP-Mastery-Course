<?php

// if(3>10){
//     echo "3 is less than 10";
// }

// $number=1;
// if($number<=0){
//     goto error_block1;
// }
// error_block1:
//     echo "I will be executed for all numbers";