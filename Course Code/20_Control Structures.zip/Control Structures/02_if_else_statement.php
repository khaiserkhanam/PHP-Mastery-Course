<?php
// $data=false;
// if($data){
//     echo "Iam true condition";
// }else{
//     echo "Iam false condition";
// }


// $data=false;
// if($data || 1){
//     echo "Iam true condition";
// }else{
//     echo "Iam false condition";
// }



// Person can vote or not
// $age=15;
// if( $age>=18 ) {
//     echo "Person can vote";
// }else{
//     echo "Person cannot vote";
// }

// Reverse condition
// $age=15;
// if( !($age>=18) ) {
//     echo "Person cannot vote";
// }else{
//     echo "Person can vote";
// }


// Multiple echos
// $data=false;
// if($data || 1){
//     echo "Iam true condition";
//     echo "My name is Khanam";
// }else{
//     echo "Iam false condition";
//     echo "Iam invisible";
// }


// Without curly braces
// $data=false;
// if($data || 1)
//     echo "Iam true condition";
// else
//     echo "Iam false condition";


// $data=false;
// if($data || 0){
//     echo "Iam true condition";
//     echo "My name is Khanam";
// }
// else{
//     echo "Iam false condition";
//     echo "Iam invisible";
// }

//  One line  

// $data=false;
// if($data || 1) echo "Iam true condition"; else   echo "Iam false condition";


// $username="Khanam";
// $isLogin=false;

// Find if the student is passed or failed.
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<h1>if else statement</h1>
<?php
if($username && $isLogin){
    ?>
    <h2>Welcome to website</h2>
    <?php

}else{
    ?>
    <h2>Welcome to website, you have limited access</h2>
    <?php
}
?>
</body>
</html>