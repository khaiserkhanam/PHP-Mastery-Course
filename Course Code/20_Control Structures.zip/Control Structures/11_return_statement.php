<?php

// Example 1:
// function name($myname){
//     return $myname;
// }
// $a=name("Khanam");
// echo $a."<br>";


// Example 2:
// function name1($myname,$age){
//     return $myname;
//     return $age;
// }
// $b=name1("Riya",24);
// echo $b."<br>";



// Example 3:
function jobOffer($offer) {
    if( empty($offer) ){
        echo "No Job Offers yet <br>";
        return;
    }

//Do not execute this code if no job offers

    switch ($offer){
        case "Analyst":
            echo "Congratulation , you are offered $offer job<br>";
            break;
        case "Engineer":
            echo "Congratulation , you are offered $offer job<br>";
            break;
        default:
        echo "Invalid";
    }
}

jobOffer("Analyst");
jobOffer("Engineer");
jobOffer("");
jobOffer("");
jobOffer("");
jobOffer("");
jobOffer("");
jobOffer("");



