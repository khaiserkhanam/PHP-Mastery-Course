<?php
// $i=1;
// while($i<=50){
//     echo $i ."<br>";
//     $i++;
// }
// echo "hello";

// Even numbers
for($value=1;$value<=10;$value++){
    $result=$value%2;
    if($result==0){
        echo "Even numbers $value";
        echo "<br>";
    }
}
echo "<br>";
echo"Using while loop<br>";
$value=1;
while($value<=10){
    $result=$value%2;
    if($result==0){
        echo "Even numbers $value";
        echo "<br>";
    }
    $value++;
}