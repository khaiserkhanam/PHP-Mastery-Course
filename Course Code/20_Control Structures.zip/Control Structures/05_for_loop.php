<?php
// echo 1;
// echo "<br>";

// echo 2;
// echo "<br>";

// echo 3;
// echo "<br>";

// echo 4;
// echo "<br>";

// echo 5;
// echo "<br>";


// For Loop

// for(initialization;condition;increment/decrement){
    //code
// }


// for($i=1 ; $i<=5 ; $i++){
//     echo $i;
//     echo "<br>";
// }
// echo "Iam done";
// echo $i;
// i=1;
// 1<=5 //true
// 1

// i=2
// 2<=5 //true
// 2

// i=3
// 3<=5 //true
// 3

// i=4
// 4<=5 //true
// 4

// i=5
// 5<=5  //true
// 5

// i=6;
// 6<=5 // false


// Example : find odd numbers

// for($value=1;$value<=10;$value++){
//     $result=$value%2;
//     if($result>0){
//         echo "Odd numbers $value";
//         echo "<br>";
//     }
// }
// echo $value;

// value=1
// 1<=10;
// $result=1%2=1
// 1>0
// Odd numbers 1

// value=2
// 2<=10
// $result =2%2=0
// 0>0

// value=3

// Even numbers
// for($value=1;$value<=10;$value++){
//     $result=$value%2;
//     if($result==0){
//         echo "Even numbers $value";
//         echo "<br>";
//     }
// }
// echo $value;


// Using decrement operator
// for($value=10;$value>=1;$value--){
//     $result=$value%2;
//     if($result>0){
//         echo "Odd numbers $value";
//         echo "<br>";
//     }
// }
// echo $value;


// without initialization
// $value=1;
// for(;$value<=10;$value++){
//     $result=$value%2;
//     if($result==0){
//         echo "Even numbers $value";
//         echo "<br>";
//     }
// }


// without increment operator
// $value=1;
// for(;$value<=10;){
//     $result=$value%2;
//     if($result==0){
//         echo "Even numbers $value";
//         echo "<br>";
//     }
//     $value++;
// }