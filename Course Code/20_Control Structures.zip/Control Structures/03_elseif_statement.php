<?php
$grade=50;

// if($grade>=90){
//     echo "Grade : A";
// }else if($grade>=80){
//     echo "Grade : B";
// }else if($grade>=70){
//     echo "Grade : C";
// }else if($grade>=60){
//     echo "Grade : D";
// }
// else{
//     echo "Fail";
// }

// if($grade>=90){
//     echo "Grade : A";
// }else if($grade>=80){
//     echo "Grade : B";
// }else if($grade>=70){
//     echo "Grade : C";
// }else if($grade>=60){
//     echo "Grade : D";
// }

// echo "I have checked for the result , but no condition matches";

// Find number is even or odd
$number="5";
if ( $number%2==0 ){
    echo "$number is even number";
}else if ( $number%2!=0 ){
    echo "$number is odd number";
}