<?php
// $family=["Mother","Father","Sister","Brother","Myself"];
// foreach($family as $values){
//     echo $values. "<br>";
// }

// Using for loop
// for($i=0;$i<count($family);$i++){
//     echo $family[$i] ."<br>";
// }

// $person = [
//     "name" => "John",
//     "age" => 25,
//     "city" => "New York"
// ];

// foreach($person as $key=>$values){
//     echo "$key-$values <br>"; 
// }