<?php
// $i=1;
// do{
// echo $i;
// $i++;
// }while($i<=5);

$i=6;
do{
echo $i;
$i++;
}while($i<=5);
echo $i;


$i=6;
while($i<=5){
    echo $i;
$i++;
}
