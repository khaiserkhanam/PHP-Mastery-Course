<?php
function findOddNumbers($max): array {
    $resultArray = [];
    for ($counter = 1; $counter <= $max; $counter++) {
        if ($counter % 2 !== 0) {
            $resultArray[] = $counter;
        }
    }
    return $resultArray;
  }
  
  $oddNumbers = findOddNumbers(10);
print_r($oddNumbers);
  