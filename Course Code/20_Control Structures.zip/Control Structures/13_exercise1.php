<!doctype html>
<html>
<head>
    <title>
        Control Structures
    </title>
</head>
<body>

<h1>Exercise 1: Multiplication table</h1>
<table border="1">
    <?php
    for ($tablenum = 1; $tablenum <= 10; $tablenum++) {
        echo "<tr>";
        echo "<td colspan='10'>Multiplication table for $tablenum</td>";
        echo "</tr>";
        for ($value = 1; $value <= 10; $value++) {
            echo "<tr>";
            echo "<td>$tablenum * $value = " . $tablenum * $value . "</td>";
            echo "</tr>";
        }
    }
    ?>
</table>


</body>
</html>
