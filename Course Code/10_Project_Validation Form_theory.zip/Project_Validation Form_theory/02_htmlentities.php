<?php
$myname="My name 'is' <strong>Khanam</strong><br>";
// echo $myname;
// echo htmlentities($myname);
// echo htmlentities($myname,ENT_COMPAT);
// echo htmlentities($myname,ENT_QUOTES);
// echo htmlentities($myname,ENT_NOQUOTES);
echo html_entity_decode($myname);
print_r(get_html_translation_table(HTML_ENTITIES));


?>