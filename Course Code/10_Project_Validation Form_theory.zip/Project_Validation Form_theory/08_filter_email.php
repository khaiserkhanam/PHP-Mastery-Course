<?php
$email="kha_nam($#_)@gmail//com";
$sanitize=filter_var($email,FILTER_SANITIZE_EMAIL);
echo $sanitize;
if(filter_var($sanitize,FILTER_VALIDATE_EMAIL)){
    echo "email is valid";
}else{
    echo "email is not valid";
}
?>