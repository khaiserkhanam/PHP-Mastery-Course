<?php

// ucfirst(str);

$myname="khanam others";
$var= ucfirst($myname);
// echo $myname;
echo $var;
echo ucwords($myname);
?>