<?php
$fruit="apple<br>";
echo $fruit;

// Array
$terms=array("PHP","MySQL","SQL");
var_dump($terms);
// echo $terms;
echo implode("|",$terms);

// Associative arrays
echo "<br>";
$fruit_data=array("fruit"=>"apple","quantity"=>"5kg" ,"price"=>100);
var_dump($fruit_data);
echo $fruit_data["fruit"];
echo $fruit_data["quantity"];
echo $fruit_data["price"];

$fruit_data["quantity"]='6kg';
echo $fruit_data["quantity"];



?>