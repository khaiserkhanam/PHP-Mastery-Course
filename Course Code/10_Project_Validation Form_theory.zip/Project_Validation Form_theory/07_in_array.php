<?php

$fruits = array("apple", "orange");

if (in_array("banana", $fruits)) {
    echo "Found banana in the array!";
} else {
    echo "Banana not found in the array.";
}

?>