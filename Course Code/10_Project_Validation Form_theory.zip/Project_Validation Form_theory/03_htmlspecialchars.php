<?php
// echo "HTML SPECIALCHAR";
echo htmlspecialchars($myname);
echo htmlspecialchars_decode($myname);

print_r(get_html_translation_table(HTML_SPECIALCHARS));
?>