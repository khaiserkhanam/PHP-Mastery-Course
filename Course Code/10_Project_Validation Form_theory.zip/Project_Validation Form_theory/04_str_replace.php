<?php

$string="Hello World";
echo $string;
// str_replace(search,replace,subject,count)

echo str_replace("World","PHP",$string);

$data="Apple, Mango,Strawberry";
$fruits=array("apple","mango","Strawberry");
$colors=array("red","yellow","pink");
echo str_replace($fruits,$colors,$data)

?>