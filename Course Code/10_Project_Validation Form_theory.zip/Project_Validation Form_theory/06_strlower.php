<?php

$myname="KHaNam";
// echo $myname;
// echo ucfirst($myname);
echo ucfirst(strtolower($myname));

?>