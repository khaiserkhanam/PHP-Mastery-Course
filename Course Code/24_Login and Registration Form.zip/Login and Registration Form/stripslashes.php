<?php
// $str="An apple a day keeps doctor away";
// echo $str;

// $str="An apple a day keeps \'doctor\' away";
// echo $str;


$str="An apple a day keeps \'doctor\' away";
echo stripslashes($str);