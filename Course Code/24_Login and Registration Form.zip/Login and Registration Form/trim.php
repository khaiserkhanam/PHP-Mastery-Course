<?php
// $str="Hello World";
// echo $str;

// $str="  Hello World";
// echo $str;


// $str="  Hello World";
// echo trim($str);


// $str="  Hello World  ";
// echo trim($str);



// $str="__Hello World__";
// echo trim($str,"_");