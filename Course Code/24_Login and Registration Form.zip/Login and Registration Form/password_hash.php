<?php
$password="Khanam123";
echo $password;

echo "<br>";

$hashed_password=password_hash($password,PASSWORD_DEFAULT);
echo $hashed_password;
echo "<br>";
// password_verify();

$password_login="Khanam1234";
if(password_verify($password_login,$hashed_password)){
    echo "Password match";
}else{
    echo "Password do not match";
}