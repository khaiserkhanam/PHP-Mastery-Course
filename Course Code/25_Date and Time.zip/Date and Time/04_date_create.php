<?php
$date=date_create("2050-04-08");
echo date_format($date,'Y-m-d');
echo "<br>";
$now=date_create();
echo date_format($now,'Y-m-d H:i:s');