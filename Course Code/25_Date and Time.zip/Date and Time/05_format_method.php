<?php

echo date_create('now')->format('Y-m-d H:i:s');
echo "<br>";
echo date_create('+1 day')->format('Y-m-d H:i:s');
echo "<br>";
echo date_create('-1 day')->format('Y-m-d H:i:s');