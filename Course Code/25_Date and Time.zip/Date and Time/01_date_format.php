<?php
echo "Time:" .date('d-m-y');
echo "<br>";
echo "Time:" .date('D-M-Y');