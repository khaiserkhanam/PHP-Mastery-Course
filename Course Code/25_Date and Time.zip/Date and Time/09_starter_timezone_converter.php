<!DOCTYPE html>
<html>
<head>
    <title>Timezone Converter</title>
</head>
<body>
    <h1>Timezone Converter</h1>
    <p>Current Time:</p>
    <form method="post" action="">
        <label for="timezone">Select Timezone:</label>
        <select id="timezone" name="timezone">
        <option value="">------Select Option--------</option>
            <option value="Pacific/Midway">Midway Island, Samoa</option>
            <option value="Pacific/Honolulu">Hawaii</option>
            <option value="America/Anchorage">Alaska</option>
            <option value="America/Los_Angeles">Pacific Time (US & Canada)</option>
            <option value="Asia/Kolkata">Asia/Kolkata</option>
            <!-- Add more timezone options as needed -->
        </select>
        <input type="submit" value="Convert">
    </form>
</body>
</html>
