<?php

echo "Time: " .date("d-m-y h:i:s:a");
echo "<br>";
echo "Time: " .date("D-M-Y H:i:s:A");
echo "<br>";

echo "Milliseconds:" .time();
echo "<br>";
$time=time()+1000;
echo $time;


echo "<br>";
echo date("D-M-Y H:i:s:A",$time);
echo date("D-M-Y H:i:s:A",$time);