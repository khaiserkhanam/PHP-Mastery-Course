<!DOCTYPE html>
<html>
<head>
    <title>Timezone Converter</title>
</head>
<body>
    <h1>Timezone Converter</h1>
    <p>Current Time: <?php  echo date('Y-m-d H:i:s') ;?></p>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']  ?>">
        <label for="timezone">Select Timezone:</label>
        <select id="timezone" name="timezone">
        <option value="">------Select Option--------</option>
            <option value="Pacific/Midway">Midway Island, Samoa</option>
            <option value="Pacific/Honolulu">Hawaii</option>
            <option value="America/Anchorage">Alaska</option>
            <option value="America/Los_Angeles">Pacific Time (US & Canada)</option>
            <option value="Asia/Kolkata">Asia/Kolkata</option>
            <!-- Add more timezone options as needed -->
        </select>
        <input type="submit" value="Convert">
    </form>
    <?php
if($_SERVER['REQUEST_METHOD']=='POST'){
   if(!empty($_POST['timezone'])){
$selectedTimeZone=$_POST['timezone'];
date_default_timezone_set($selectedTimeZone);
echo "<p>Selected time : ". date('Y-m-d H:i:s')."</p>";
   }else{
    echo "<p>Please select a timezone.</p>";
   }
}
?>
</body>
</html>
