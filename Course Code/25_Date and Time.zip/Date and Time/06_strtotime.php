<?php
// jan 1 1970 00:00:00 GMT

// $dateString="2025-04-08";
// $timeStamp=strtotime($dateString);
// echo $timeStamp;

// $dateString="next Thursday";
// $timeStamp=strtotime($dateString);
// echo $timeStamp;



$timeStamp=strtotime("2025-04-08 08:00:00");
echo $timeStamp;
echo "<br>";
echo time();
if(time()>=$timeStamp){
    echo "Time is ahead";
}else{
    echo "Time is not ahead";
}