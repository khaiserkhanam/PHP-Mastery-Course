<?php
// $date1=time();
// sleep(10);
// $date2=time();
// $diff=($date1-$date2)/60;
// echo $diff;


$start1=date_create('2050-09-11 12:09:00');
$start2=date_create('2050-09-12 12:10:00');
$diffDate=date_diff($start2,$start1);
print_r($diffDate);