<?php

date_default_timezone_set("Asia/Kolkata");
$timeStamp=date_default_timezone_get();
echo $timeStamp;
echo "<br>";
echo $timeStamp;

echo date("m-d-y h:i:s:a");