<?php

// $currentDateTime=new DateTime();
// echo $currentDateTime->format("Y-m-d H:i:s");


// $specificDateTime=new DateTime('2030-09-12 12:00:00');
// echo $specificDateTime->format("Y-m-d H:i:s");


// $specificDateTime=new DateTime('2030-09-12');
// $specificDateTime->modify('+5 day');
// echo $specificDateTime->format("Y-m-d");


// $DifferenceDate1=new DateTime('2030-09-12');
// $DifferenceDate2=new DateTime('2031-10-11');

// $interval=$DifferenceDate2->diff($DifferenceDate1);

// echo $interval->format("%R%a days");