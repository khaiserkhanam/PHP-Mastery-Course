<?php

// @
// include 'file_not_present.php';
// @include 'file_not_present.php';
// echo "Hello World";

@$value=1/0;
echo $value;
echo "Hello World";
?>

