<?php
// $x=5;
// $shift=2;
// $result=$x<<$shift;
// echo $result;

// $x=5;
// $shift=1;
// $result=$x<<$shift;
// echo $result;

