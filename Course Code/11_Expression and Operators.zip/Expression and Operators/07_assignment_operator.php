<?php
/*
    = - Assignment Operator to assign values
    += - Add Assignment Operator
    .=- String Assignment Operator
    -= - Subtract Assignment Operator
    *= - Multiple Assignment Operator
    /= - Divide Assignment Operator
    %= - Modulus Assignment Operator
*/


// = - Assignment Operator to assign values
// $age=10;
// $myname="Khanam";


// += - Add Assignment Operator
// $count=1;
// echo $count;
// $count=$count+1;
// $count+=1;
// $count+=10;
// echo $count;


// .=- String Assignment Operator
// $myname="Khaiser";
// $myname.="_";
// $myname.="Khanam";
// echo $myname;
// $myname="Khaiser"."_"."Khanam";
// echo $myname;


// -= - Subtract Assignment Operator
// $month=12;
// $month=$month-1;
// $month-=1;
// echo $month;


// *= - Multiple Assignment Operator
// $square=2;
// $square=$square*$square;
// $square*=$square;
// echo $square;

// /= - Divide Assignment Operator
// $result=5;
// $result=$result/2;
// $result/=3;
// echo $result;


// %= - Modulus Assignment Operator
// $result=11;
// $result%=2;
// echo $result;


