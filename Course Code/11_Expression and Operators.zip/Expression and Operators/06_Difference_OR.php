<?php
// Logical operators: Difference between Logical OR - ||

// echo true || false;
// echo false OR false;

$result1=false || true;
echo $result1?"true":"false";

$result2="apple" OR true;
echo $result2;