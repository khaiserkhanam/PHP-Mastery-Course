<!-- Logical operators: Difference between Logical and - && -->

<?php
// &&- higher priority
// and - lower priority

$data1=(true && true) and true;
echo $data1?"true":"false";
$data2=true and false;
echo $data2?"true":"false";