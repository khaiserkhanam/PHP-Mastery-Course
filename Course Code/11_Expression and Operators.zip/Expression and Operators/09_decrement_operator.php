<?php
// Decrement Operator
/*
1- Pre- Decrement --variable
2- Post- Decrement variable--
*/

// -=
// $counter=10;
// $counter-=9;
// echo $counter;


// 1- Pre- Decrement --variable
// $x=10;
// echo $x;
// echo --$x;

// $a=90;
// $b=--$a;
// echo $b;
// echo $a;

// /2- Post- Decrement variable--
// $x=10;
// echo $x;
// echo $x--;
// echo $x;

// $a=90;
// $b=$a--;
// echo $b;
// echo $a;

// Examples
// $num=3;
// $result=2*$num; //6
// $result=2*--$num;
// echo $result;


// $sum=11;
// echo $sum--; //11
// echo $sum; //10

// echo --$sum; //9
// echo $sum; //9


// Assignment:
// $a = 8;
// $b = --$a - $a--;   //7-7=0
// echo "The value of \$b is: $b";
// echo "The value of \$a is: $a";
