<?php
/*
    AND - both values should be true
    OR - any one value can be true
    && - both values should be true
    || - any one value can be true
    *! -  if not
*/

// $email="Khanam@gmail1.com";
// $password="password123";

// Login credentials
// $emailLogin="Khanam@gmail.com";
// $passwordLogin="password123";

// Logical AND(&&)
// $successLogin=($email==$emailLogin && $password==$passwordLogin)?"Welcome $email":"Welcome Guest";
// echo $successLogin;


// Logical OR(||)
// $username="Khanam1";
// $usernameLogin="Khanam";
//  $successLogin=($email==$emailLogin || $username==$usernameLogin)?"Welcome $email":"Welcome Guest";
// echo $successLogin;

// NOT OperatoR(!)
// $a=1;
// echo !$a?"a is true":"a is false";