<?php

// Syntax:
// (condition) ? expression_if_true : expression_if_false;
// Ternary Operator ?:

// echo (true)?"True value":"False value";
// echo (false)?"True value":"False value";

// $flag1=(true)?"True value":"False value";
// echo $flag1;

// $age=15;
// $canVote=($age>=18)?"Person can vote":"Person cannot vote";
// echo $canVote;

// $canVote=($age>=18)?true:false;
// echo "Can Vote:" .(($canVote)?'Yes':'No');