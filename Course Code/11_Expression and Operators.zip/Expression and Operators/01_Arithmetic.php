<?php
/* 
Addition +
Subtraction -
Multiplication *
Division \
Modulus %
Exponential **
*/
$totalMarks=600;
$maths = 60;
$science = 68;
$social = 88;
$english = 65;
$hindi = 78;
$kannada = 59;

$result=$maths+$science+$social+$english+$hindi+$kannada;
echo $result;
// $result1="Total marks : $maths+$science+$social+$english+$hindi+$kannada is $result ";
// $result1="Total marks" .$maths+$science+$social+$english+$hindi+$kannada;
// echo $result1;

// $totalMarksLost=$totalMarks-$result;
// echo $totalMarksLost;

// echo $social *$social;
// echo $social**2;
// echo 2**3;
// A**2+2*A*B+b**2;


// echo 4/2;
// echo 33/2;


// $percentage=($result/$totalMarks) *100;
// echo "$percentage%";


// echo 3%6;
// echo 6%3;