<?php
    /*
     * & - AND
     * | - OR
     * ^ - XOR
     * ~ - NOT 
     */

// Binary values
    // 0  - 0000
    // 1  - 0001
    // 2  - 0010
    // 3  - 0011
    // 4  - 0100
    // 5  - 0101
    // 6  - 0110
    // 7  - 0111
    // 8  - 1000
    // 9  - 1001
    // 10 - 1010

    // & AND
    // $x=5;
    // $y=1;
    // $result=$x & $y;
    // echo $result;


    // $x=5;
    // $y=4;
    // $result=$x & $y;
    // echo $result;


    // | OR
    // $x=5;
    // $y=4;
    // $result=$x | $y;
    // echo $result;


    // ^ XOR
    // $x=5;
    // $y=9;
    // $result=$x ^ $y;
    // echo $result;

    // ~ NOT
    $x=1;
    echo ~$x;
