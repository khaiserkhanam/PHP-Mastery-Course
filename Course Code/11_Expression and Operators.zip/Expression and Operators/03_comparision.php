<?php
/*
EQUAL TO : ==
DATA TYPE AND VALUE IDENTICAL : ===
NOT EQUAL TO : != / <> /  !==
LESS THAN : <
GREATER THAN : >
LESS THAN OR EQUAL TO : <=
GREATER THAN OR EQUAL TO : >=
*/

// $a="5";
// echo var_dump($a);
// $b=5;
// echo var_dump($b);
// $result=($a==$b);
// $result=($a===$b);
// echo $result?"Equal":"Not Equal";


// $x="7";
// $y=7;
// $result=($x!=$y);
// $result=($x<>$y);
// $result=($x!==$y);
// echo $result?"Not Equal":"Equal";


// $a=10;
// $b=10;
// echo ($a<$b)?"$a is less than $b": "$a is not less  than $b";
// echo ($a>$b)?"$a is greater than $b": "$a is not greater  than $b";
// echo ($a>=$b)?"yes it is": "its not";
// echo ($a<=$b)?"yes it is": "its not";

// $customerName="Khanam";
// $purchaseTreshold=100;
// $amountPurchased=200;
// echo ($amountPurchased>=$purchaseTreshold)?"Discount is available for $customerName":"Discount is not available for $customerName";