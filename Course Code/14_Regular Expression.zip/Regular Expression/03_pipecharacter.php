<?php
// $quote="Believe you can and you're halfway there just believe it";
// |
// $search=preg_match_all("/believe|halfway/i",$quote);
// echo $search;

// $search=preg_match_all("/believe|halfway/i",$quote,$array);
// echo $search;
// echo "<pre>";
// print_r($array);
// echo "</pre>";
// echo $array[0][0];
// echo $array[0][1];
// echo $array[0][2];


// $search=preg_match_all("/t|w|a|e|b/i",$quote,$array);
// echo $search;
// echo "<pre>";
// print_r($array);
// echo "</pre>";


// $search=preg_match_all("/success|z/i",$quote,$array);
// echo $search;
// echo "<pre>";
// print_r($array);
// echo "</pre>";

// $quote="Believe you can and you're halfway there just believe it - 100 200";
// $search=preg_match_all("/100|200/i",$quote,$array);
// echo $search;
// echo "<pre>";
// print_r($array);
// echo "</pre>";