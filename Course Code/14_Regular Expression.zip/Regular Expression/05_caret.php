<?php
// The caret ^ has a special meaning inside square brackets [] in a regular expression pattern. When used as the first character within square brackets, it negates the character class, meaning it matches any character that is not in the specified set.
// ^

$quote="Believe you can and you're halfway there just believe it -100 and 200 percent you will succeed";
echo $quote;
echo "<br>";

// $search=preg_match_all("/[^s]/", $quote);
// echo $search;

// $search=preg_match_all("/[^s]/", $quote,$array);
// echo $search;
// echo "<pre>";
// print_r($array);
// echo "<\pre>";



// $search=preg_match_all("/[^0-9]/", $quote,$array);
// echo $search;
// echo "<pre>";
// print_r($array);
// echo "<\pre>";

$search=preg_match_all("/[^12]/", $quote,$array);
echo $search;
echo "<pre>";
print_r($array);
echo "<\pre>";