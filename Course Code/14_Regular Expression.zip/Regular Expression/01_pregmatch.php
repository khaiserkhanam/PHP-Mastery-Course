<?php
$quote="Believe you can and you're halfway there halfway";
echo $quote;
// $search=preg_match("/halfway/",$quote);
// echo $search?"Match Found":"Match not found";

// $search=preg_match("/HALFWAY/i",$quote);
// echo $search?"Match Found":"Match not found";

// $search=preg_match("/HALWAY/i",$quote,$array);
// echo $search?"Match Found":"Match not found";
// print_r($array);