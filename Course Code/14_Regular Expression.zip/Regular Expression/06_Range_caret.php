<?php
$data="Everything has BEAUTY, but not everyone sees it- 123";
echo $data;
echo "<br>";

// Things to find
/*
* Find a-z
* Find a-f
* Find A-H
* Find a-hA-H
* Find 0-9a-h
* Dont select 0-9a-z
* Dont select 0-9a-i

*/

// $result=preg_match_all("/[a-z]/",$data,$array);
// echo $result;
// echo "<pre>";
// print_r($array);
// echo "</pre>";

// $result=preg_match_all("/[a-f]/",$data,$array);
// echo $result;
// echo "<pre>";
// print_r($array);
// echo "</pre>";

// $result=preg_match_all("/[A-H]/",$data,$array);
// echo $result;
// echo "<pre>";
// print_r($array);
// echo "</pre>";


// $result=preg_match_all("/[a-hA-H]/",$data,$array);
// echo $result;
// echo "<pre>";
// print_r($array);
// echo "</pre>";


// $result=preg_match_all("/[0-9a-h]/",$data,$array);
// echo $result;
// echo "<pre>";
// print_r($array);
// echo "</pre>";

// $result=preg_match_all("/[^0-9a-z]/i",$data,$array);
// echo $result;
// echo "<pre>";
// print_r($array);
// echo "</pre>";

// $result=preg_match_all("/[^0-9a-i]/i",$data,$array);
// echo $result;
// echo "<pre>";
// print_r($array);
// echo "</pre>";


function addNumbers($num1, $num2) {
    $sum = $num1 + $num2;
    return $sum;
}

$result=addNumbers(4, 2); // Call the function with arguments 4 and 2
echo "The sum is: " . $result; // Output: The sum is: 6

