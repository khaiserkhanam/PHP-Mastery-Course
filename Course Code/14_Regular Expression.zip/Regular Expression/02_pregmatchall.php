<?php
$quote="Believe you can and you're halfway there halfway, just believe it";
echo $quote;
echo "<br>";


// $search=preg_match_all("/Believe/",$quote);
// echo $search;

// $search=preg_match_all("/BELIEVE/i",$quote);
// echo $search;


$search=preg_match_all("/BELIEVE/i",$quote,$array);
echo $search?"Match found":"Match not found";
echo "<pre>";
print_r($array);
echo "</pre>";