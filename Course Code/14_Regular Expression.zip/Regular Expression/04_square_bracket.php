<?php
$quote="Believe you can and you're halfway there just believe it -100 and 200 percent you will succeed";
echo $quote;
echo "<br>";

// []
// $search=preg_match_all("/a|b|c|/",$quote);

// $search=preg_match_all("/[a-z]/",$quote);
// echo $search;


// $search=preg_match_all("/[a-c]/",$quote);
// echo $search;


// $search=preg_match_all("/[0-9]/",$quote);
// echo $search;


// $search=preg_match_all("/[a-zA-Z]/",$quote);
// echo $search;

// $search=preg_match_all("/[aeiou]/",$quote);
// echo $search;
// $search=preg_match_all("/[a|e|i|o|u]/",$quote);
// echo $search;


$search=preg_match_all("/[aeiou]/",$quote,$array);
echo $search;
echo "<pre>";
print_r($array);
echo "<\pre>";