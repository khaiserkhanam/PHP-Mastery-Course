<?php
// Check if fileData is set and not empty
if(isset($_GET['fileData']) && !empty($_GET['fileData'])) {
    // Sanitize file name to prevent directory traversal
    $file = basename($_GET['fileData']) . ".pdf";
    

    // Path to your PDF files directory
    $filePath =$file;

    // Check if the file exists
    if(file_exists($filePath)) {
        // Force download
        header("Content-Disposition: attachment; filename=" . urlencode($file));
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Description: File Transfer");
        header("Content-Length: " . filesize($filePath));

        // Read the file and output it
        readfile($filePath);

        // Exit script after file download
        exit;
    } else {
        // File not found
        echo "File not found.";
    }
} else {
    // fileData parameter is missing or empty
    echo "Invalid file request.";
}
?>
