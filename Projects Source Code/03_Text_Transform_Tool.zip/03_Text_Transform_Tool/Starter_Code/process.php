<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Text Transformation Result</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Text Transformation Result</h1>

        <p>Original Text:</p>
        <p>Result:</p>
        <p><a href="index.php">Back to Text Transformation Tool</a></p>
    </div>
</body>
</html>
