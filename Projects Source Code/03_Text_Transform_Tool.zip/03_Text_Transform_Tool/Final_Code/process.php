<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve user input
    $inputText = $_POST['inputText'];
    $operation = $_POST['operation'];
    $substring = isset($_POST['substring']) ? $_POST['substring'] : '';

    // Perform the selected operation
    switch ($operation) {
        case 'uppercase':
            $result = strtoupper($inputText);
            break;
        case 'lowercase':
            $result = strtolower($inputText);
            break;
        case 'reverse':
            $result = strrev($inputText);
            break;
        case 'charCount':
            $result = "Character Count: " . strlen($inputText);
            break;
            case 'substr':
                // Check if the start and length are provided
                if (isset($_POST['start']) && isset($_POST['length'])) {
                    $start = $_POST['start'];
                    $length = $_POST['length'];
                    // Use substr to extract a portion of the input text
                    $result = substr($inputText, $start, $length);
                } else {
                    $result = "Start and length not provided for substr operation";
                }
                break;
        case 'explode':
            $words = explode(' ', $inputText);
            $result = "Exploded Text: " . implode(', ', $words);
            break;
        case 'wordCount':
            $result = "Number of Words: " . str_word_count($inputText);
            break;
        case 'removeSpaces':
            $result = str_replace(' ', '', $inputText);
            break;
        case 'shuffle':
            $result = str_shuffle($inputText);
            break;
        case 'findPosition':
            $position = strpos(strtolower($inputText), strtolower($substring));
            $result = ($position !== false) ? "Found at position: $position" : "Not found";
            break;
        case 'wordWrap':
            $result = wordwrap($inputText, 10, "<br>");
            break;
        default:
            $result = "Invalid operation";
    }
} else {
    // Redirect to the main page if accessed directly
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Text Transformation Result</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Text Transformation Result</h1>

        <p>Original Text: <?php echo $inputText; ?></p>
        <p>Result: <?php echo $result; ?></p>

        <?php
        if ($operation === 'findPosition') {
            echo "<p>Substring '$substring' ";
            if (strpos($result, 'Found') !== false) {
                echo "found at position: $position</p>";
            } else {
                echo "not found</p>";
            }
        }
        ?>

        <p><a href="index.php">Back to Text Transformation Tool</a></p>
    </div>
</body>
</html>
