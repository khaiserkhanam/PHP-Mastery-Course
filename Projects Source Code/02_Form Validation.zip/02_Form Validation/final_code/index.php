<?php include './includes/connect.php';
$username_msg="Username should be between 3 and 30 characters";
$place_msg="Place should be between 3 and 30 characters";
$phone_msg="Phone number should be atmost 10 digits";
$invalid_email="Invalid Email Address";
$fill_all_fields="Please fill all fields";
$error_messages=array();

if(isset($_POST['submit'])){
  // Validate input
    $username=htmlspecialchars($_POST['username']);
    // $username=mysqli_real_escape_string($con,$_POST['username']);
    $email=$_POST['email'];
    $place=htmlspecialchars($_POST['place']);
    $phone=preg_replace('/[^0-9]/','',$_POST['phone']);// Remove non-numeric characters


 // Additional username validation
    $username=str_replace(" ","",$username);
    // Remove extra spaces
    $username=ucfirst(strtolower($username));// Convert to lowercase and capitalize first letter


  // Additional username validation
    $place=str_replace(" ","",$place);  // Remove extra spaces
    $place=ucfirst(strtolower($place));// Convert to lowercase and capitalize first letter

    if(empty($username)  || empty($email)  || empty($phone)  || empty($place)){
      $error_messages[]=$fill_all_fields;
    }else{
    // Perform other validations only if data is provided
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match('/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/', $email)) {
      $error_messages[]=$invalid_email;
  }
    if(strlen($phone)!==10 || !ctype_digit($phone) || $phone<=0){
      $error_messages[]=$phone_msg;
    }
    if(strlen($username)<3 || strlen($username)>30){
      $error_messages[]=$username_msg;
    }
    if(strlen($place)<3 || strlen($place)>30){
      $error_messages[]=$place_msg;
    }

      // If no validation errors, proceed with database insertion
    if(empty($error_messages)){
      // Check if the username or email already exists
      $check_query="Select * from validate where username='$username' or email='$email'";
      $check_query=mysqli_query($con,$check_query);
      if(!$check_query){
        echo "<script>alert('Error checking existing data')</script>";
      }
      if(mysqli_num_rows($check_query)>0){
        $existing_user_email_error="Username or Email already exist";
      // Optionally, you can use $existing_user_email_error for further display or processing
        $error_messages[]=$existing_user_email_error;
        // echo $existing_user_email_error;
      }else{
        // validate and sanitizing input
        $username=mysqli_real_escape_string($con,$username);
        $email=mysqli_real_escape_string($con,$email);
        $phone=mysqli_real_escape_string($con,$phone);
        $place=mysqli_real_escape_string($con,$place);
      // Perform the query
        $insert_query="insert into validate (username,email,phone,place) values ('$username','$email','$phone','$place')";
        $result=mysqli_query($con,$insert_query);
      // Check for success
        if($result){
          echo "<script>alert('Data inserted successfully')</script>";
          echo "<script>window.open('index.php','_self')</script>";
          
        }else{
          die(mysqli_error($result));
        }
        }
      }
    }
  
    
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Validation</title>
    <link rel="stylesheet" href="style.css?v1=a">
</head>
<body>
 
<div class="form_container">
  <h1 class="heading">Form Validation</h1>
  <?php
   if(in_array($fill_all_fields,$error_messages)) echo '<span class="error_messages" id="all_fields_error">'.$fill_all_fields.'</span>';
      ?>
  <div>
    <div class="form_group" id="user_email_exist">
    <span class="error_messages"><?php  echo isset($existing_user_email_error)? $existing_user_email_error:"";?></span>
    </div>
    <form action="" method="post">
      <input type="text" name="username" placeholder="Enter your username"  class="input_field"  autocomplete="off"/>
      <?php
   if(in_array($username_msg,$error_messages)) echo '<span class="error_messages">'.$username_msg.'</span>';
      ?>
      
      <input type="text" name="email" placeholder="Enter your email"  class="input_field" autocomplete="off"/>
      <?php
   if(in_array($invalid_email,$error_messages)) echo '<span class="error_messages">'.$invalid_email.'</span>';
      ?>
      <input type="number" name="phone" placeholder="Enter your phone" class="input_field" autocomplete="off"/>

      <?php
   if(in_array($phone_msg,$error_messages)) echo '<span class="error_messages">'.$phone_msg.'</span>';
      ?>
      <input type="place" name="place" placeholder="Enter your place"  class="input_field" autocomplete="off"/>
      <?php
   if(in_array($place_msg,$error_messages)) echo '<span class="error_messages">'.$place_msg.'</span>';
      ?>
      <button type="submit" class="btn" name="submit">Submit Form</button>
    </form>
</div>
</div>

<!-- JavaScript code to clear input fields -->
<script>
    // Clear error messages when input fields are focused
    document.addEventListener('DOMContentLoaded', function () {
        const form = document.querySelector('form');
        const inputFields = form.querySelectorAll('input');
        const allFieldsError = document.getElementById('all_fields_error');
        const userEmailError = document.getElementById('user_email_exist');

        inputFields.forEach(function(input) {
            input.addEventListener('focus', function() {
                if (allFieldsError) {
                    allFieldsError.textContent = ''; // Clear the "Please fill in all fields" error
                    
                }
                if(userEmailError){
                    userEmailError.textContent='';
                }

                const errorSpan = this.nextElementSibling;
                if (errorSpan && errorSpan.classList.contains('error_messages')) {
                    errorSpan.textContent = '';
                }
            });
        });
    });
</script>
</body>
</html>