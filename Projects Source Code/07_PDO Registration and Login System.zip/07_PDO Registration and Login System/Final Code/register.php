<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mydatabase";


try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Function to validate input data
        function validateInput($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }

        // Validate and sanitize input data
        $username = validateInput($_POST["username"]);
        $password = validateInput($_POST["password"]);
        $confirm_password = validateInput($_POST["cpassword"]);
        $gender = validateInput($_POST["gender"]);
        $phone = validateInput($_POST["mobile"]);
        $email = validateInput($_POST["email"]);

        // Check if passwords match
        if ($password !== $confirm_password) {
            echo "Passwords do not match. Please enter matching passwords.";
        } else {
            // Hash the password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Check if username and email already exist
            $stmt_check = $conn->prepare("SELECT * FROM users WHERE username = :username OR email = :email");
            $stmt_check->bindParam(':username', $username);
            $stmt_check->bindParam(':email', $email);
            $stmt_check->execute();

            if ($stmt_check->rowCount() > 0) {
                echo "Username or email already exists. Please choose a different username or email.";
            } else {
                // Insert data into the database
                $stmt_insert = $conn->prepare("INSERT INTO users (username, password, gender, phone, email) VALUES (:username, :password, :gender, :phone, :email)");
                $stmt_insert->bindParam(':username', $username);
                $stmt_insert->bindParam(':password', $hashed_password);
                $stmt_insert->bindParam(':gender', $gender);
                $stmt_insert->bindParam(':phone', $phone);
                $stmt_insert->bindParam(':email', $email);

                $stmt_insert->execute();

                // Display registration successful message
                echo "Registration successful! Redirecting to login page...";

                // Redirect to login page after a short delay
                header("refresh:2;url=login.php");
                exit();
            }
        }
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

$conn = null;
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Registration and Login System</title>
    <link rel="stylesheet" href="css/style.css" />
  </head>
  <body>
    <h1 class="heading">Registration System in PHP</h1>
    <div class="container">
      <div class="form_container">
        <form action="" method="post" class="form">
          <h3 class="form_heading">Sign Up</h3>

          <input
            type="text"
            placeholder="Enter your username"
            class="input_fields"
            name="username" required
          />
          <input
            type="email"
            placeholder="Enter your email"
            class="input_fields"
            name="email" required
          />
          <input
            type="password"
            placeholder="Enter your password"
            class="input_fields"
            name="password" required
          />
          <input
            type="password"
            placeholder="Confirm Password"
            class="input_fields"
            name="cpassword" required
          />
          <select name="gender" required class="input_fields">
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
          </select>
          <input
            type="number"
            placeholder="Enter your phone number"
            class="input_fields"
            name="mobile" required
          />
          <p class="form_question">
            Already have an account?
            <a href="login.php" class="login_text">Login here</a>
          </p>
          <input type="submit" value="Sign Up" class="btn" />
        </form>
      </div>
      <div class="image_container">
        <img src="images/blue-scenary.png" alt="Registration Image" />
      </div>
    </div>

    <footer class="footer">
      <p>
        Made with 💖 by Khanam
        <a href="https://www.youtube.com/c/StepbyStep_KhanamCoding"
          >Visit here</a
        >
      </p>
    </footer>
    <script src="script.js"></script>
  </body>
</html>
