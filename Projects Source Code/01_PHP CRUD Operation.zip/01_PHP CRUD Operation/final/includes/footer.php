<div class="footer">
      <p>All right reserved- Made with 💖 by Khanam</p>
    </div>
  </body>
</html>