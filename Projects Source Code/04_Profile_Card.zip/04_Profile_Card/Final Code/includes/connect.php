<?php
$con = mysqli_connect('localhost','root','','php_tutorial');
if(!$con){
    echo "Connection failed";
}
?>

<!-- NOTE : Give the database name which you have created. -->