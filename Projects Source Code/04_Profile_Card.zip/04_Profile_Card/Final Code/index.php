<?php
include('./includes/connect.php');

$error = '';

if(isset($_POST['submit'])){
    // Check if image file is empty
    if(empty($_FILES['image_file']['name'])) {
        $error = "Please insert an image first.";
    } else {
        $image=$_FILES['image_file'];
        $imageFileName=$image['name'];
        $imageFileTemp=$image['tmp_name'];

        $separateFilename=explode('.',$imageFileName);
        $fileExtension=strtolower(end($separateFilename));

        $image_extensions=['jpeg','jpg','png'];
        if(in_array($fileExtension,$image_extensions)){
            $upload_image='images/'.$imageFileName;
            move_uploaded_file($imageFileTemp,$upload_image);
            $insert_image="INSERT INTO img_upload (image) VALUES ('$upload_image')";
            $result=mysqli_query($con,$insert_image);
            if($result){
                echo "Data inserted successfully";
            }else{
                die(mysqli_error($con));
            }
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Card</title>
    <link rel="stylesheet" href="style.css">

</head>
<body>
<?php if(!empty($error)): ?>
            <p class='error_message'><?php echo $error; ?></p>
        <?php endif; ?>
    <div class="container">
        <div class="form_container">
        <h2>Profile Card</h2>
        <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post" enctype="multipart/form-data">
            <div class="form_group">
                <input type="file" class="input_field" name="image_file">
            </div>
            <div class="form_group">
                <input type="submit" class="submit_btn" name="submit">
            </div>
        </form>
        <a href="display.php" class="link">View Profile</a>
    </div>
    </div>
</body>
</html>
