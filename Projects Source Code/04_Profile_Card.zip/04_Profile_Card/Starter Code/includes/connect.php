<?php
$con = mysqli_connect('localhost','root','','database_name');
if(!$con){
    echo "Connection failed";
}
?>

<!-- NOTE : Give the database name which you have created. -->