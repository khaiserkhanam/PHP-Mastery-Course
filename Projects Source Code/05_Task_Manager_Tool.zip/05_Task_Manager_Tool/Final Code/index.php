<?php
// Start session to store tasks
session_start();
// Function to add a new task to the list
function addTask($task)
{
    if (!isset($_SESSION['tasks'])) {
        $_SESSION['tasks'] = [];
}

    // Check if the task is already added
    $taskExists = array_column($_SESSION['tasks'], 'task');
    if (in_array($task, $taskExists)) {
        echo "<p class='error_message'>Task already added: $task</p>";
        return;
    }
    array_push($_SESSION['tasks'], [
        'task' => $task,
        'completed' => false,
    ]);
    echo "<p class='message'>Task added</p>";
}

// Function to display tasks based on completion status and sorting
function displayTasks($completedFilter = 'all', $sortFilter = 'asc')
{
    if (empty($_SESSION['tasks'])) {
        echo "<p class='error_message'>No tasks found.</p>";
        return;
    }
        // Filter tasks based on completion status
        $filteredTasks = array_filter($_SESSION['tasks'], function ($task) use ($completedFilter) {
            return ($completedFilter === 'all') || ($completedFilter === 'completed' && $task['completed']) || ($completedFilter === 'incomplete' && !$task['completed']);
        });

          // Sort tasks based on user selection
    usort($filteredTasks, function ($a, $b) use ($sortFilter) {
        if ($sortFilter === 'asc') {
            return strcmp($a['task'], $b['task']);
        } elseif ($sortFilter === 'desc') {
            return strcmp($b['task'], $a['task']);
        }
        return 0;
    });
    echo "<ul>";
    foreach ($filteredTasks as $index => $task) {
        $status = $task['completed'] ? 'Completed' : 'Incomplete';
        echo "<li>[$index] {$task['task']} <span>($status)</span></li>";
    }
    echo "</ul>";

    
}

// Function to mark a task as completed
function completeTask($index)
{
    if (isset($_SESSION['tasks'][$index]) && !$_SESSION['tasks'][$index]['completed']) {
        $_SESSION['tasks'][$index]['completed'] = true;
        echo "<p class='message'>Task completed: {$_SESSION['tasks'][$index]['task']}</p>";
    } else {
        echo "<p class='error_message'>Invalid task index or task already completed</p>";
    }
}


// Function to remove an incomplete task
function removeTask($index)
{
    if (isset($_SESSION['tasks'][$index]) && !$_SESSION['tasks'][$index]['completed']) {
        $removedTask = $_SESSION['tasks'][$index]['task'];
        array_splice($_SESSION['tasks'], $index, 1);
        echo "<p class='message'>Task removed: $removedTask</p>";
    } else {
        echo "<p class='error_message'>Invalid task index or task already completed.</p>";
    }
}

// Function to clear all tasks
function clearAllTasks()
{
    $_SESSION['tasks'] = [];
    echo "<p class='message'>All tasks cleared.</p>";
}


// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle form submissions
    if (isset($_POST['addTask'])) {
        $task = $_POST['task'];
        // Add task function to be executed
        addTask($task);
    } elseif (isset($_POST['completeTask'])) {
        $index = $_POST['completedTaskIndex'];
        // Completed task function to be executed
        completeTask($index);
    } elseif (isset($_POST['removeTask'])) {
        $index = $_POST['removeTaskIndex'];
        // Remove task function to be executed
        removeTask($index);
    } elseif (isset($_POST['clearAllTasks'])) {
        // Clear task function to be executed
        clearAllTasks();
    }
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task Manager App</title>
    <link rel="stylesheet" href="style.css?v1=b">
</head>
<body>
    <div class="main_task_container">
    <div class="container">
        <h2>Task Manager App</h2>

         <!-- Form to add a new task -->
         <form method="post" action="">
            <label for="task">Add Task:</label>
            <input type="text" id="task" name="task" required>
            <button type="submit" name="addTask">Add Task</button>
        </form>


          <!-- Form to select completed or incomplete tasks and Sorting and filtering -->
          <form method="post" action="">
            <!-- Label 1 -->
            <label for="completedFilter">Show:</label>
            <select id="completedFilter" name="completedFilter">
                <option value="all">All</option>
                <option value="completed">Completed</option>
                <option value="incomplete">Incomplete</option>
            </select>


            <!-- Label 2 -->
            <label for="sortFilter">Sort:</label>
            <select id="sortFilter" name="sortFilter">
                <option value="asc">Ascending</option>
                <option value="desc">Descending</option>
            </select>

            <button type="submit">Filter and Sort</button>
        </form>

        
          <!-- Form to mark a task as completed -->
          <form method="post" action="">
            <label for="completedTaskIndex">Complete Task (Enter Task Index):</label>
            <input type="number" id="completedTaskIndex" name="completedTaskIndex" required>
            <button type="submit" name="completeTask">Complete</button>
        </form>


          <!-- Form to remove an incomplete task -->
          <form method="post" action="">
            <label for="removeTaskIndex">Remove Task (Enter Task Index):</label>
            <input type="number" id="removeTaskIndex" name="removeTaskIndex" required>
            <button type="submit" name="removeTask">Remove</button>
        </form>

        <!-- Display the list of tasks -->
        <?php
        if (isset($_POST['completedFilter']) && isset($_POST['sortFilter'])) {
            $completedFilter = $_POST['completedFilter'];
            $sortFilter = $_POST['sortFilter'];
            displayTasks($completedFilter, $sortFilter);
        } else {
            // Initially display "No tasks found"
            displayTasks();
        }
        ?>


           <!-- Form to clear all tasks -->
           <form method="post" action="">
            <button type="submit" class="clear" name="clearAllTasks">Clear All Tasks</button>
        </form>
    </div>
    </div>
</body>
</html>