<?php
include '../connect.php';
// Check if ID is provided in the URL
// Check if ID is provided in the URL
if (!isset($_GET['id'])) {
    echo "User ID not provided.";
    exit;
}

// Delete user
$id = $_GET['id'];
echo "User ID to delete: " . $id; // Debugging statement

$sql = "DELETE FROM user_data WHERE id = :id";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(':id', $id);

try {
    $stmt->execute();
    echo "User deleted successfully.";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>