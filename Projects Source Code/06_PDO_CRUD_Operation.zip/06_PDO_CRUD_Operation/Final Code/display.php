<?php
include '../connect.php';
// Function to retrieve all users
function getAllUsers($pdo) {
    $sql = "SELECT * FROM user_data";
    $stmt = $pdo->query($sql);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Get all users
$users = getAllUsers($pdo);
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Display Data</title>
    <link rel="stylesheet" href="style.css?va=1" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
    />
  </head>
  <body>
    <div class="table_container">
      <table class="table">
         <thead>
<tr>
  <th>Sl No</th>
  <th>Username</th>
  <th>Email</th>
  <th>Mobile</th>
  <th>Place</th>
  <th>Action</th>
</tr>
</thead>
<tbody>
  
<tbody>
            <?php foreach ($users as $user): ?>
            <tr>
              <td><?= $user['id']?></td>
                <td><?= $user['username'] ?></td>
                <td><?= $user['phone'] ?></td>
                <td><?= $user['place'] ?></td>
                <td><?= $user['email'] ?></td>
                <td>
                <a href="update.php?id=<?= $user['id'] ?>"><i class='fa-solid fa-pen-to-square'></i
    ></a>
    <a href="delete.php?id=<?= $user['id'] ?>" onclick="return confirm('Are you sure you want to delete this user?')"><i class='fa-solid fa-trash'></i></a>
  </td>
               
            </tr>
            <?php endforeach; ?>
        </tbody>
      </table>
    </div>
   
  </body>
</html>
