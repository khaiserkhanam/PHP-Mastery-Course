<?php
include '../connect.php';
// Function to retrieve user details by ID
function getUserById($pdo, $id) {
    $sql = "SELECT * FROM user_data WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// Check if ID is provided in the URL
if (!isset($_GET['id'])) {
    echo "User ID not provided.";
    exit;
}

// Get user details by ID
$id = $_GET['id'];
$user = getUserById($pdo, $id);

// Update user data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $phone = $_POST['phone'];
    $place = $_POST['place'];
    $email = $_POST['email'];

    $sql = "UPDATE user_data SET username = :username, phone = :phone, place = :place, email = :email WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':phone', $phone);
    $stmt->bindParam(':place', $place);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':id', $id);

    try {
        $stmt->execute();
        echo "User updated successfully.";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update User</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
    <form action="" method="post" class="form">
    <div class="form-input-container">
          <input
            autocomplete="off"
            type="text"
            class="form-input"
            name="username"
            value="<?= $user['username'] ?>"
          />     
        </div>

        
        <div class="form-input-container">
          <input
            autocomplete="off"
            type="number"
            class="form-input"
            name="phone"
            value="<?= $user['phone'] ?>"
          />
        </div>

        <div class="form-input-container">
          <input
            autocomplete="off"
            type="text"
            class="form-input"
            name="place"
            value="<?= $user['place'] ?>"
          />
        </div>

        <div class="form-input-container">
          <input
            autocomplete="off"
            type="text"
            class="form-input"
            name="email"
            value="<?= $user['email'] ?>"
          />
        </div>
        <input type="submit" value="Update" class="form-btn"/>
    </form>
</div>
</body>
</html>
