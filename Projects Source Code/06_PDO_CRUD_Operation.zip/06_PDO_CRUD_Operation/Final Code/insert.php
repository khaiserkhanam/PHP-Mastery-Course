<?php
include './includes/connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $phone = $_POST['phone'];
    $place = $_POST['place'];
    $email = $_POST['email'];

    // Check if email already exists
    $check_sql = "SELECT COUNT(*) FROM user_data WHERE email = :email";
    $check_stmt = $pdo->prepare($check_sql);
    $check_stmt->bindParam(':email', $email);
    $check_stmt->execute();
    $email_count = $check_stmt->fetchColumn();

    if ($email_count > 0) {
        echo "User with this email already exists.";
    } else {
        // Insert new user
        $insert_sql = "INSERT INTO user_data (username, phone, place, email) VALUES (:username, :phone, :place, :email)";
        $stmt = $pdo->prepare($insert_sql);
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':phone', $phone);
        $stmt->bindParam(':place', $place);
        $stmt->bindParam(':email', $email);

        try {
            $stmt->execute();
            echo "User added successfully";
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }
}
?>
